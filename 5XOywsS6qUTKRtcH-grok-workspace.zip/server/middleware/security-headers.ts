/**
 * Global security headers for deployed Nitro responses.
 * Do not set X-Frame-Options — the live preview is iframed.
 */
type EventLike = {
  node?: { res?: { setHeader: (name: string, value: string) => void } };
};

export default function securityHeaders(event: EventLike) {
  const res = event.node?.res;
  if (!res?.setHeader) return;
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
  res.setHeader(
    "Permissions-Policy",
    "camera=(), microphone=(), geolocation=(), usb=(), payment=(self), interest-cohort=()",
  );
  res.setHeader("X-DNS-Prefetch-Control", "off");
  res.setHeader("Cross-Origin-Opener-Policy", "same-origin-allow-popups");
  res.setHeader("X-Permitted-Cross-Domain-Policies", "none");
  res.setHeader("Origin-Agent-Cluster", "?1");
}
