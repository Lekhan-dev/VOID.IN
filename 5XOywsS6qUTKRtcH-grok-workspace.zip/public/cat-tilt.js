(function () {
  if (location.pathname.indexOf("/ops") === 0) return;
  if (window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  if (window.matchMedia && window.matchMedia("(hover: none)").matches) return;

  function bind(card) {
    if (card.dataset.tilt === "1") return;
    card.dataset.tilt = "1";
    var ticking = false;
    var last = null;
    card.addEventListener(
      "mousemove",
      function (e) {
        last = e;
        if (ticking) return;
        ticking = true;
        requestAnimationFrame(function () {
          ticking = false;
          if (!last) return;
          var r = card.getBoundingClientRect();
          if (!r.width || !r.height) return;
          var px = (last.clientX - r.left) / r.width;
          var py = (last.clientY - r.top) / r.height;
          card.style.setProperty("--ry", ((px - 0.5) * 10).toFixed(2) + "deg");
          card.style.setProperty("--rx", ((0.5 - py) * 8).toFixed(2) + "deg");
        });
      },
      { passive: true },
    );
    card.addEventListener("mouseleave", function () {
      last = null;
      card.style.setProperty("--rx", "0deg");
      card.style.setProperty("--ry", "0deg");
    });
  }

  function scan() {
    var cards = document.querySelectorAll(".cat-card");
    for (var i = 0; i < cards.length; i++) bind(cards[i]);
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", scan);
  else scan();
  document.addEventListener("click", function () {
    setTimeout(scan, 50);
  });
})();
