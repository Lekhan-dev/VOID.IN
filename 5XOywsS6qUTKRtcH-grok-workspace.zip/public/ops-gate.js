(function () {
  if (location.pathname.indexOf("/ops") !== 0) return;
  var PIN = "vPVMmVaa";
  try {
    if (sessionStorage.getItem("void_ops_ok") === "1") {
      document.documentElement.dataset.ops = "1";
    }
  } catch (e) {}
  document.addEventListener(
    "submit",
    function (e) {
      var t = e.target;
      if (!t || t.id !== "ops-gate") return;
      e.preventDefault();
      e.stopImmediatePropagation();
      var inp = t.querySelector("input");
      var v = inp && inp.value ? String(inp.value).trim() : "";
      var err = t.querySelector("[data-gate-err]");
      if (v !== PIN) {
        if (err) err.textContent = "Wrong PIN";
        return;
      }
      if (err) err.textContent = "";
      try {
        sessionStorage.setItem("void_ops_ok", "1");
      } catch (ex) {}
      document.documentElement.dataset.ops = "1";
      window.dispatchEvent(new Event("void-ops-unlock"));
    },
    true,
  );
})();
