(function () {
  var KEY = "void_cart";

  function read() {
    try {
      var raw = localStorage.getItem(KEY);
      if (!raw) return { state: { items: [] }, version: 0 };
      var data = JSON.parse(raw);
      if (!data || !data.state || !Array.isArray(data.state.items)) {
        return { state: { items: [] }, version: 0 };
      }
      return data;
    } catch (e) {
      return { state: { items: [] }, version: 0 };
    }
  }

  function write(data) {
    localStorage.setItem(KEY, JSON.stringify(data));
    window.dispatchEvent(new Event("void-cart-changed"));
  }

  function count(items) {
    var n = 0;
    for (var i = 0; i < items.length; i++) n += items[i].qty || 0;
    return n;
  }

  function paint(n) {
    var els = document.querySelectorAll("[data-cart-count]");
    for (var i = 0; i < els.length; i++) {
      els[i].textContent = String(n);
      els[i].hidden = n < 1;
    }
  }

  function add(id, name, price) {
    var data = read();
    var items = data.state.items;
    var found = null;
    for (var i = 0; i < items.length; i++) {
      if (items[i].id === id) found = items[i];
    }
    if (found) found.qty += 1;
    else items.push({ id: id, name: name, price: price, qty: 1, img: "" });
    write(data);
    paint(count(items));
  }

  document.addEventListener(
    "click",
    function (e) {
      var t = e.target;
      if (!t || !t.closest) return;
      var btn = t.closest("[data-add-cart]");
      if (!btn || btn.disabled) return;
      e.preventDefault();
      e.stopPropagation();
      if (btn.getAttribute("data-sold") === "1") return;
      var id = btn.getAttribute("data-id") || "";
      var name = btn.getAttribute("data-name") || "Piece";
      var price = Number(btn.getAttribute("data-price") || "0");
      if (!id) return;
      add(id, name, price);
      btn.textContent = "Added";
      setTimeout(function () {
        if (btn.getAttribute("data-sold") === "1") return;
        btn.textContent = "Quick Add";
      }, 900);
    },
    true,
  );

  function boot() {
    paint(count(read().state.items));
  }
  if (document.body) boot();
  else document.addEventListener("DOMContentLoaded", boot);
})();
