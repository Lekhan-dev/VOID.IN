import { Link } from "@tanstack/react-router";
import { ArrowUpRight } from "lucide-react";
import type { ProductCategory } from "@/lib/products";

export type CategoryTile = {
  title: string;
  copy: string;
  img: string;
  cat: ProductCategory;
  delay: number;
};

export function CategoryCard({ title, copy, img, cat }: CategoryTile) {
  return (
    <div className="cat-stage">
      <Link
        to="/shop"
        search={{ cat }}
        className="cat-card group relative block aspect-[16/9] overflow-hidden rounded-lg border border-border"
      >
        <img
          src={img}
          alt={title}
          width={900}
          height={506}
          loading="eager"
          decoding="async"
          className="cat-card-img h-full w-full object-cover"
        />
        <span className="cat-card-shine" aria-hidden="true" />
        <span className="cat-card-depth" aria-hidden="true" />
        <div className="absolute inset-0 flex flex-col justify-end bg-gradient-to-t from-bg via-bg/45 to-transparent p-5">
          <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-primary">Shop</p>
          <h3 className="cat-card-title mt-1 font-display text-2xl font-bold">{title}</h3>
          <p className="text-sm text-muted">{copy}</p>
          <span className="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-fg">
            View drop
            <ArrowUpRight className="cat-card-arrow size-4" />
          </span>
        </div>
      </Link>
    </div>
  );
}

export const CATEGORY_TILES: CategoryTile[] = [
  {
    title: "Tees & Tops",
    copy: "Oversized. Heavy. Loud.",
    img: "/categories/tees.jpg",
    cat: "tees",
    delay: 0,
  },
  {
    title: "Hoodies",
    copy: "400 GSM. Zero compromise.",
    img: "/categories/hoodies.jpg",
    cat: "hoodies",
    delay: 90,
  },
  {
    title: "Bottoms",
    copy: "Cargos. Baggy. Built to move.",
    img: "/categories/bottoms.jpg",
    cat: "bottoms",
    delay: 180,
  },
  {
    title: "Accessories",
    copy: "Caps. Bags. The details.",
    img: "/categories/accessories.jpg",
    cat: "accessories",
    delay: 270,
  },
];
