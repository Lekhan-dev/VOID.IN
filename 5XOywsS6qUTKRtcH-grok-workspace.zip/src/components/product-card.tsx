import { ImageOff } from "lucide-react";
import { stockOf, useOps } from "@/lib/ops";
import { productCode, type Product } from "@/lib/products";
import { inr } from "@/lib/utils";

export function ProductPlaceholder({ name }: { name: string }) {
  return (
    <div
      className="flex h-full w-full flex-col items-center justify-center gap-2 bg-elevated"
      aria-hidden="true"
    >
      <div className="grid size-12 place-items-center rounded-full border border-dashed border-border">
        <ImageOff className="size-5 text-muted" />
      </div>
      <p className="font-display text-xs font-bold tracking-[0.2em] text-muted">NO IMAGE</p>
      <p className="max-w-[80%] truncate px-2 text-center text-[10px] text-muted">{name}</p>
    </div>
  );
}

export function ProductCard({ product }: { product: Product }) {
  const stock = useOps((s) => stockOf(s.stock, product.id));
  const soldOut = stock <= 0;

  return (
    <article className="prod-card overflow-hidden rounded-lg border border-border bg-surface">
      <div className="relative aspect-[3/4] overflow-hidden bg-elevated">
        <ProductPlaceholder name={product.name} />
        {product.badge && !soldOut && (
          <span
            className={
              "absolute left-3 top-3 rounded-md px-2 py-1 text-[10px] font-bold uppercase tracking-wide " +
              (product.badge === "hot"
                ? "bg-hot text-white"
                : product.badge === "limited"
                  ? "border border-primary bg-elevated text-primary"
                  : "bg-primary text-[#070707]")
            }
          >
            {product.badge}
          </span>
        )}
        {soldOut && (
          <span className="absolute left-3 top-3 rounded-md bg-bg px-2 py-1 text-[10px] font-bold uppercase tracking-wide text-hot">
            Sold out
          </span>
        )}
        <button
          type="button"
          data-add-cart
          data-id={product.id}
          data-name={product.name}
          data-price={String(product.price)}
          data-sold={soldOut ? "1" : "0"}
          disabled={soldOut}
          className="absolute inset-x-3 bottom-3 flex min-h-11 items-center justify-center rounded-md bg-fg text-sm font-semibold text-bg disabled:cursor-not-allowed disabled:opacity-50"
        >
          {soldOut ? "Sold out" : "Quick Add"}
        </button>
      </div>
      <div className="p-3 md:p-4">
        <p className="text-[10px] uppercase tracking-[0.14em] text-muted">
          {product.catLabel} · {productCode(product.id)}
        </p>
        <h3 className="mt-1 font-medium leading-snug">{product.name}</h3>
        <p className="mt-1 line-clamp-2 text-xs text-muted">{product.desc}</p>
        <p className="mt-2 font-semibold tabular-nums text-primary">{inr(product.price)}</p>
        <p className="mt-1 text-[11px] text-muted">
          {soldOut ? "Not available" : stock <= 3 ? stock + " left" : "In stock"}
        </p>
      </div>
    </article>
  );
}
