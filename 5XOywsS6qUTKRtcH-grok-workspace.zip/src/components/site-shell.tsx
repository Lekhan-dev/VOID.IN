import { Link, useRouterState } from "@tanstack/react-router";
import { Facebook, Instagram, Menu, ShoppingBag, Youtube, X } from "lucide-react";
import { useEffect, useState } from "react";
import { Toaster } from "sonner";
import { UserButton } from "@/lib/auth/gates";
import { useCurrentUser } from "@/lib/auth/use-current-user";
import { cartCount, useCart } from "@/lib/cart";
import { useOps } from "@/lib/ops";
import { SOCIALS } from "@/lib/socials";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/", label: "Home" },
  { to: "/shop", label: "Shop" },
  { to: "/track", label: "Track" },
  { to: "/write", label: "Write" },
  { to: "/tagged", label: "Tagged" },
  { to: "/checkout", label: "Cart" },
] as const;

function AuthSlot() {
  const user = useCurrentUser();
  const [local, setLocal] = useState<{ name: string } | null>(() => {
    try {
      const raw = sessionStorage.getItem("void_me");
      return raw ? (JSON.parse(raw) as { name: string }) : null;
    } catch {
      return null;
    }
  });

  useEffect(() => {
    if (!user) return;
    try {
      sessionStorage.removeItem("void_me");
    } catch {
      /* ignore */
    }
    setLocal(null);
  }, [user]);

  if (user) return <UserButton />;
  if (local) {
    return (
      <span className="hidden text-sm font-semibold md:inline">{local.name}</span>
    );
  }
  return (
    <>
      <Link to="/login" className="hidden text-sm font-semibold text-muted hover:text-fg md:inline">
        Sign in
      </Link>
      <Link
        to="/login"
        search={{ mode: "signup" }}
        className="hidden min-h-9 items-center rounded-full border border-border px-3 text-sm font-semibold md:inline-flex"
      >
        Sign up
      </Link>
    </>
  );
}

export function SiteShell({ children }: { children: React.ReactNode }) {
  const [open, setOpen] = useState(false);
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const count = useCart((s) => cartCount(s.items));

  useEffect(() => {
    void useCart.persist.rehydrate();
    void useOps.persist.rehydrate();
    const sync = () => {
      void useCart.persist.rehydrate();
    };
    window.addEventListener("void-cart-changed", sync);
    window.addEventListener("storage", sync);
    return () => {
      window.removeEventListener("void-cart-changed", sync);
      window.removeEventListener("storage", sync);
    };
  }, []);

  if (pathname.startsWith("/ops")) {
    return (
      <div className="min-h-dvh bg-bg text-fg">
        <Toaster theme="dark" position="bottom-center" />
        {children}
      </div>
    );
  }

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <Toaster theme="dark" position="bottom-center" />
      <header className="sticky top-0 z-40 border-b border-border bg-bg">
        <div className="mx-auto flex h-14 w-[min(1200px,92%)] items-center justify-between">
          <Link to="/" className="font-display text-xl font-extrabold tracking-tight">
            VOID
          </Link>
          <nav className="hidden items-center gap-8 text-sm font-medium md:flex">
            {NAV.map((n) => (
              <Link
                key={n.to}
                to={n.to}
                preload="intent"
                className={cn(
                  "transition-colors hover:text-primary",
                  pathname === n.to ? "text-fg" : "text-muted",
                )}
              >
                {n.label}
              </Link>
            ))}
          </nav>
          <div className="flex items-center gap-2">
            <AuthSlot />
            <Link
              to="/checkout"
              preload="intent"
              className="relative grid size-11 place-items-center rounded-full border border-border"
              aria-label="Cart"
            >
              <ShoppingBag className="size-5" />
              <span
                data-cart-count
                hidden={count < 1}
                className="absolute -right-1 -top-1 grid min-w-5 place-items-center rounded-full bg-black px-1 text-[10px] font-bold text-white tabular-nums"
              >
                {count}
              </span>
            </Link>
            <button
              type="button"
              className="grid size-11 place-items-center rounded-full border border-border md:hidden"
              aria-label={open ? "Close menu" : "Open menu"}
              onClick={() => setOpen((v) => !v)}
            >
              {open ? <X className="size-5" /> : <Menu className="size-5" />}
            </button>
          </div>
        </div>
        {open && (
          <div className="border-t border-border px-[4%] py-4 md:hidden">
            {NAV.map((n) => (
              <Link
                key={n.to}
                to={n.to}
                preload="intent"
                onClick={() => setOpen(false)}
                className="block py-3 text-lg font-medium"
              >
                {n.label}
              </Link>
            ))}
            <Link to="/login" onClick={() => setOpen(false)} className="block py-3 text-lg font-medium">
              Sign in
            </Link>
            <Link
              to="/login"
              search={{ mode: "signup" }}
              onClick={() => setOpen(false)}
              className="block py-3 text-lg font-medium"
            >
              Sign up
            </Link>
            <p className="pt-2 text-xs text-muted">Founded by Lekhan. Guest makers too.</p>
          </div>
        )}
      </header>
      <main>{children}</main>
      <footer className="border-t border-border">
        <div className="mx-auto flex w-[min(1200px,92%)] flex-col gap-3 py-3 md:flex-row md:items-center md:justify-between">
          <p className="font-display text-sm font-extrabold">
            VOID <span className="font-sans text-[11px] font-normal text-muted">· India only · Lekhan</span>
          </p>
          <div className="flex items-center gap-2">
            {SOCIALS.map((s) => (
              <a
                key={s.id}
                href={s.href}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={s.label}
                className="grid size-9 place-items-center rounded-full border border-border text-muted hover:border-primary hover:text-primary"
              >
                {s.id === "ig" && <Instagram className="size-4" />}
                {s.id === "x" && (
                  <svg viewBox="0 0 24 24" className="size-3.5 fill-current" aria-hidden="true">
                    <path d="M18.2 2H21l-6.6 7.5L22 22h-6.8l-5.3-7-6.1 7H2.2l7-8L2 2h7l4.8 6.4L18.2 2Zm-1.2 18.2h1.9L7.1 3.7H5.1l11.9 16.5Z" />
                  </svg>
                )}
                {s.id === "fb" && <Facebook className="size-4" />}
                {s.id === "yt" && <Youtube className="size-4" />}
              </a>
            ))}
          </div>
          <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs">
            <Link to="/shop" className="hover:text-primary">
              Shop
            </Link>
            <Link to="/track" className="hover:text-primary">
              Track
            </Link>
            <Link to="/write" className="hover:text-primary">
              Write
            </Link>
            <Link to="/tagged" className="hover:text-primary">
              Tagged
            </Link>
            <Link to="/terms" className="hover:text-primary">
              Terms
            </Link>
            <Link to="/privacy" className="hover:text-primary">
              Privacy
            </Link>
            <Link to="/ops" className="hover:text-primary">
              Staff
            </Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
