import { useEffect, useState } from "react";
import { createPortal } from "react-dom";
import { TAGGED_LOOKS, type TaggedLook } from "@/lib/tagged";
import { IG_TAG } from "@/lib/socials";

export function TaggedGrid() {
  const [open, setOpen] = useState<TaggedLook | null>(null);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(null);
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener("keydown", onKey);
    };
  }, [open]);

  return (
    <>
      <div className="tagged-grid grid grid-cols-2 gap-3 md:grid-cols-3">
        {TAGGED_LOOKS.map((look, i) => (
          <button
            key={look.id}
            type="button"
            style={{ animationDelay: `${i * 90}ms` }}
            className="tagged-card overflow-hidden rounded-lg border border-border bg-surface text-left"
            onClick={() => setOpen(look)}
          >
            <span className="relative block overflow-hidden">
              <img
                src={look.img}
                alt={look.handle + " in " + look.piece}
                width={600}
                height={750}
                loading="lazy"
                decoding="async"
                className="tagged-card-img aspect-[4/5] w-full object-cover"
              />
              <span className="tagged-hint">Click to read {look.name}’s story</span>
            </span>
            <span className="block px-3 py-2">
              <span className="flex items-center justify-between gap-2 text-xs">
                <span className="font-semibold">{look.handle}</span>
                <span className="text-muted">{look.city}</span>
              </span>
              <span className="mt-1 line-clamp-2 text-[11px] text-muted">{look.caption}</span>
            </span>
          </button>
        ))}
      </div>

      {mounted &&
        open &&
        createPortal(
          <div className="tagged-modal" role="dialog" aria-modal="true">
            <button type="button" className="tagged-modal-bg" aria-label="Close" onClick={() => setOpen(null)} />
            <div className="tagged-modal-panel">
              <img src={open.img} alt="" className="max-h-64 w-full object-cover md:max-h-none md:h-full" />
              <div className="p-5">
                <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-primary">
                  Written by {open.name}
                </p>
                <h3 className="mt-1 font-display text-2xl font-bold">{open.name}</h3>
                <p className="text-sm text-muted">
                  {open.handle} · {open.city}
                </p>
                <p className="mt-1 text-xs font-semibold text-primary">{open.piece}</p>
                <p className="mt-4 text-base leading-relaxed">{open.caption}</p>
                <p className="mt-4 text-xs text-muted">Tagged {IG_TAG} on Instagram. Picked by VOID.</p>
                <button
                  type="button"
                  className="mt-5 min-h-11 w-full rounded-full bg-primary text-sm font-semibold text-[#070707]"
                  onClick={() => setOpen(null)}
                >
                  Close
                </button>
              </div>
            </div>
          </div>,
          document.body,
        )}
    </>
  );
}
