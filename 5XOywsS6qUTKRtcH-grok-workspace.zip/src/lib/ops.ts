import { create } from "zustand";
import { persist } from "zustand/middleware";
import { productCode, PRODUCTS } from "./products";

export type OrderStatus = "new" | "packing" | "shipped" | "out" | "delivered" | "cancelled";

export type OpsItem = {
  id: string;
  code: string;
  name: string;
  qty: number;
  price: number;
};

export type OpsOrder = {
  id: string;
  createdAt: number;
  name: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  pincode: string;
  items: OpsItem[];
  total: number;
  payment: string;
  status: OrderStatus;
};

export type DeskNote = {
  id: string;
  createdAt: number;
  name: string;
  email: string;
  message: string;
  read: boolean;
};

type OpsState = {
  stock: Record<string, number>;
  orders: OpsOrder[];
  seenIds: string[];
  notes: DeskNote[];
  setStock: (id: string, qty: number) => void;
  placeOrder: (order: Omit<OpsOrder, "status">) => void;
  setStatus: (id: string, status: OrderStatus) => void;
  markSeen: (id: string) => void;
  markAllSeen: () => void;
  addNote: (note: Omit<DeskNote, "id" | "createdAt" | "read">) => void;
  markNoteRead: (id: string) => void;
};

function defaultStock(): Record<string, number> {
  const stock: Record<string, number> = {};
  for (const p of PRODUCTS) stock[p.id] = 12;
  stock["leather-jacket"] = 2;
  stock["shadow-bomber"] = 3;
  stock["varsity-jacket"] = 0;
  stock["puffer-vest"] = 4;
  return stock;
}

function seedOrders(): OpsOrder[] {
  return [
    {
      id: "VOID-100024",
      createdAt: Date.now() - 1000 * 60 * 40,
      name: "Aarav Mehta",
      phone: "9876543210",
      address: "12 Linking Road",
      city: "Mumbai",
      state: "MH",
      pincode: "400050",
      items: [
        { id: "chaos-tee", code: productCode("chaos-tee"), name: "Chaos Oversized Tee", qty: 1, price: 1299 },
        { id: "core-cap", code: productCode("core-cap"), name: "Core Cap", qty: 1, price: 799 },
      ],
      total: 2197,
      payment: "Paid via Razorpay",
      status: "new",
    },
    {
      id: "VOID-100018",
      createdAt: Date.now() - 1000 * 60 * 180,
      name: "Diya Sharma",
      phone: "9123456780",
      address: "88 CP Block",
      city: "Delhi",
      state: "DL",
      pincode: "110001",
      items: [
        { id: "night-hoodie", code: productCode("night-hoodie"), name: "Night Mode Hoodie", qty: 1, price: 2499 },
      ],
      total: 2598,
      payment: "Paid via Razorpay",
      status: "shipped",
    },
  ];
}

export function nextOrderCode(taken: string[]) {
  const used = new Set(taken.map((id) => id.toUpperCase()));
  for (let i = 0; i < 40; i++) {
    const n = 100000 + Math.floor(Math.random() * 900000);
    const code = "VOID-" + n;
    if (!used.has(code)) return code;
  }
  return "VOID-" + Date.now().toString().slice(-8);
}

export const STAFF_PIN = "vPVMmVaa";

export function normStatus(status: OrderStatus): Exclude<OrderStatus, "out"> {
  return status === "out" ? "shipped" : status;
}

export function stockOf(stock: Record<string, number>, id: string) {
  return stock[id] ?? 12;
}

export const useOps = create<OpsState>()(
  persist(
    (set, get) => ({
      stock: defaultStock(),
      orders: seedOrders(),
      seenIds: seedOrders().map((o) => o.id),
      notes: [],
      setStock: (id, qty) => {
        const n = Math.max(0, Math.min(999, Math.round(qty)));
        set({ stock: { ...get().stock, [id]: n } });
      },
      placeOrder: (order) => {
        const stock = { ...get().stock };
        for (const item of order.items) {
          const have = stockOf(stock, item.id);
          stock[item.id] = Math.max(0, have - item.qty);
        }
        set({
          stock,
          orders: [{ ...order, status: "new" as const }, ...get().orders].slice(0, 200),
        });
      },
      setStatus: (id, status) => {
        const prev = get().orders.find((o) => o.id === id);
        if (!prev || status === "cancelled") return;
        if (normStatus(prev.status) === normStatus(status)) return;
        set({
          orders: get().orders.map((o) => (o.id === id ? { ...o, status } : o)),
        });
      },
      markSeen: (id) => {
        if (get().seenIds.includes(id)) return;
        set({ seenIds: [...get().seenIds, id] });
      },
      markAllSeen: () => {
        set({ seenIds: get().orders.map((o) => o.id) });
      },
      addNote: (note) => {
        const row: DeskNote = {
          id: "NOTE-" + Date.now().toString().slice(-8),
          createdAt: Date.now(),
          name: note.name,
          email: note.email,
          message: note.message,
          read: false,
        };
        set({ notes: [row, ...(get().notes ?? [])].slice(0, 200) });
      },
      markNoteRead: (id) => {
        set({
          notes: (get().notes ?? []).map((n) => (n.id === id ? { ...n, read: true } : n)),
        });
      },
    }),
    { name: "void_ops", skipHydration: true },
  ),
);

if (typeof window !== "undefined") {
  window.addEventListener("storage", (e) => {
    if (e.key === "void_ops") void useOps.persist.rehydrate();
  });
}
