export type TaggedLook = {
  id: string;
  handle: string;
  name: string;
  city: string;
  piece: string;
  img: string;
  caption: string;
};

export const TAGGED_LOOKS: TaggedLook[] = [
  {
    id: "t1",
    handle: "@aria.shift",
    name: "Aria",
    city: "Mumbai",
    piece: "Chaos Tee",
    img: "/tagged/01.jpg",
    caption: "Chaos Tee + rain on Marine Drive. Tagging VOID because this is the first drop that actually fits how I walk the city.",
  },
  {
    id: "t2",
    handle: "@dev.night",
    name: "Dev",
    city: "Delhi",
    piece: "Night Hoodie",
    img: "/tagged/02.jpg",
    caption: "Night Hoodie after a 1am metro. Heavy fabric, no logo scream. Just VOID on the tag.",
  },
  {
    id: "t3",
    handle: "@meera.void",
    name: "Meera",
    city: "Bengaluru",
    piece: "Cargo",
    img: "/tagged/03.jpg",
    caption: "Cargos for studio days. Pockets ate my keys, cables, and a sandwich. 10/10 would tag again.",
  },
  {
    id: "t4",
    handle: "@kai.drop",
    name: "Kai",
    city: "Pune",
    piece: "Core Cap",
    img: "/tagged/04.jpg",
    caption: "Core Cap on FC Road. Low profile. That’s the point. VOID picked this shot — still buzzing.",
  },
  {
    id: "t5",
    handle: "@rishi.wear",
    name: "Rishi",
    city: "Hyderabad",
    piece: "Shadow Jacket",
    img: "/tagged/05.jpg",
    caption: "Shadow Jacket for the first cold week. Wore it to a gig and three people asked where. Told them: tag @void.wear.",
  },
  {
    id: "t6",
    handle: "@niva.streets",
    name: "Niva",
    city: "Jaipur",
    piece: "Baggy",
    img: "/tagged/06.jpg",
    caption: "Baggy bottoms, pink city heat. Folded the hem twice. This is how I wanted the drop to sit.",
  },
];
