export type ProductCategory =
  | "tees"
  | "hoodies"
  | "bottoms"
  | "outerwear"
  | "accessories";

export type Product = {
  id: string;
  name: string;
  price: number;
  category: ProductCategory;
  catLabel: string;
  desc: string;
  img: string;
  badge: "new" | "hot" | "limited" | null;
};

const u = (id: string) =>
  `https://images.unsplash.com/${id}?w=800&q=80&auto=format&fit=crop`;

export const PRODUCTS: Product[] = [
  { id: "chaos-tee", name: "Chaos Oversized Tee", price: 1299, category: "tees", catLabel: "Graphic Tee", badge: "new", desc: "220 GSM cotton. Boxy oversized fit. Loud front print for daily street wear.", img: u("photo-1583743814966-8936f5b7be1a") },
  { id: "night-hoodie", name: "Night Mode Hoodie", price: 2499, category: "hoodies", catLabel: "Heavyweight", badge: "hot", desc: "400 GSM fleece. Drop shoulders. Built for late-night rides and cold AC.", img: u("photo-1556821840-3a63f95609a7") },
  { id: "utility-cargo", name: "Utility Cargo Pants", price: 1899, category: "bottoms", catLabel: "Bottoms", badge: null, desc: "Multi-pocket cargo. Relaxed fit. Durable fabric for all-day city moves.", img: u("photo-1624378439575-d8705ad7ae80") },
  { id: "shadow-bomber", name: "Shadow Bomber", price: 3499, category: "outerwear", catLabel: "Outerwear", badge: "limited", desc: "Lightweight bomber. Ribbed cuffs. Clean silhouette for night outs.", img: u("photo-1591047139829-d91aecb6caea") },
  { id: "core-cap", name: "Core Cap", price: 799, category: "accessories", catLabel: "Accessories", badge: null, desc: "Structured cap. Adjustable strap. Minimal VOID embroidery.", img: u("photo-1588850561407-ed78c282e89b") },
  { id: "relaxed-shorts", name: "Relaxed Shorts", price: 999, category: "bottoms", catLabel: "Bottoms", badge: "new", desc: "Above-knee relaxed shorts. Soft cotton. Easy summer essential.", img: u("photo-1591195853828-11db59a44f6b") },
  { id: "void-tee", name: "Void Graphic Tee", price: 1399, category: "tees", catLabel: "Graphic Tee", badge: null, desc: "Heavy cotton tee. Bold back graphic. Slightly cropped oversized cut.", img: u("photo-1576566588028-4147f3842f27") },
  { id: "storm-hoodie", name: "Storm Hoodie", price: 2699, category: "hoodies", catLabel: "Heavyweight", badge: null, desc: "Washed finish hoodie. Kangaroo pocket. Soft inside, tough outside.", img: u("photo-1578768076945-8d57054b5ba5") },
  { id: "pulse-tee", name: "Pulse Oversized Tee", price: 1199, category: "tees", catLabel: "Graphic Tee", badge: "new", desc: "Breathable mid-weight tee. Wide sleeves. Everyday Gen-Z staple.", img: u("photo-1521572163474-6864f9cf17ab") },
  { id: "drift-pants", name: "Drift Wide Pants", price: 2199, category: "bottoms", catLabel: "Bottoms", badge: "hot", desc: "Wide-leg silhouette. Elastic waist. Moves with you, looks expensive.", img: u("photo-1542272604-787c3835535d") },
  { id: "neon-tee", name: "Neon Drop Tee", price: 1249, category: "tees", catLabel: "Graphic Tee", badge: "new", desc: "High-contrast print tee. Soft hand-feel. Limited colourway drop.", img: u("photo-1618354691373-d851c5c3a990") },
  { id: "blackout-hoodie", name: "Blackout Hoodie", price: 2599, category: "hoodies", catLabel: "Heavyweight", badge: null, desc: "All-black heavyweight. Double-layered hood. Zero logos energy.", img: u("photo-1509942774185-799d268f5b9f") },
  { id: "baggy-denim", name: "Baggy Denim", price: 2499, category: "bottoms", catLabel: "Bottoms", badge: "hot", desc: "90s baggy denim. Mid wash. Room for sneakers and attitude.", img: u("photo-1541099649105-f69ad21f3246") },
  { id: "varsity-jacket", name: "Varsity Jacket", price: 3999, category: "outerwear", catLabel: "Outerwear", badge: "limited", desc: "Classic varsity cut. Contrast sleeves. Campus to street ready.", img: u("photo-1551028719-00167b16eac5") },
  { id: "bucket-hat", name: "Bucket Hat", price: 899, category: "accessories", catLabel: "Accessories", badge: null, desc: "Cotton bucket hat. Soft brim. Festival and heat essential.", img: u("photo-1521369909029-2afed882baee") },
  { id: "cargo-shorts", name: "Cargo Shorts", price: 1299, category: "bottoms", catLabel: "Bottoms", badge: null, desc: "Utility shorts with side pockets. Light fabric for humid days.", img: u("photo-1591195853828-11db59a44f6b") },
  { id: "glitch-tee", name: "Glitch Print Tee", price: 1349, category: "tees", catLabel: "Graphic Tee", badge: "new", desc: "Digital glitch artwork. Soft oversized body. Conversation starter.", img: u("photo-1562157873-818bc0726f68") },
  { id: "zip-hoodie", name: "Zip Tech Hoodie", price: 2799, category: "hoodies", catLabel: "Heavyweight", badge: "hot", desc: "Full-zip tech hoodie. Clean hardware. Layer over tees easily.", img: u("photo-1620799140408-edc6dcb6d633") },
  { id: "wide-cargo", name: "Wide Cargo Pants", price: 2099, category: "bottoms", catLabel: "Bottoms", badge: null, desc: "Extra-wide cargos. Drawcord hem. Max comfort, max pockets.", img: u("photo-1473966968600-fa801b869a1a") },
  { id: "puffer-vest", name: "Puffer Vest", price: 2999, category: "outerwear", catLabel: "Outerwear", badge: "limited", desc: "Lightweight puffer vest. Packable warmth without bulk.", img: u("photo-1544923246-77307dd28ed4") },
  { id: "beanie", name: "Core Beanie", price: 699, category: "accessories", catLabel: "Accessories", badge: null, desc: "Rib-knit beanie. Soft stretch. Winter layer that stays simple.", img: u("photo-1576871337632-b9aef4c17ab9") },
  { id: "boxy-tee", name: "Boxy Fit Tee", price: 1199, category: "tees", catLabel: "Graphic Tee", badge: null, desc: "True boxy cut. Thick collar. Pairs with cargos and denim.", img: u("photo-1586790170083-2f9ceadc732d") },
  { id: "oversized-hoodie", name: "Oversized Cloud Hoodie", price: 2699, category: "hoodies", catLabel: "Heavyweight", badge: "new", desc: "Cloud-soft fleece. Extra long sleeves. Coziest piece in the drop.", img: u("photo-1515886657613-9f3515b0c78f") },
  { id: "track-pants", name: "Track Pants", price: 1799, category: "bottoms", catLabel: "Bottoms", badge: null, desc: "Tapered track pants. Side stripe detail. Gym to street.", img: u("photo-1552902865-b72c031ac5ea") },
  { id: "denim-jacket", name: "Raw Denim Jacket", price: 3599, category: "outerwear", catLabel: "Outerwear", badge: "hot", desc: "Classic denim jacket. Raw indigo. Ages with every wear.", img: u("photo-1576995853123-5a10305d93c0") },
  { id: "socks-pack", name: "Crew Socks Pack", price: 499, category: "accessories", catLabel: "Accessories", badge: null, desc: "3-pack crew socks. Cushioned sole. Full height.", img: u("photo-1586350977771-b3b0abd50f80") },
  { id: "acid-tee", name: "Acid Wash Tee", price: 1399, category: "tees", catLabel: "Graphic Tee", badge: "new", desc: "Acid-wash texture. Vintage fade. Each piece looks slightly unique.", img: u("photo-1529374255404-311a2a4f1fd9") },
  { id: "cropped-hoodie", name: "Cropped Hoodie", price: 2299, category: "hoodies", catLabel: "Heavyweight", badge: null, desc: "Cropped length hoodie. Clean hem. Layer over high-waist fits.", img: u("photo-1618354691438-25bc04584c23") },
  { id: "parachute-pants", name: "Parachute Pants", price: 2399, category: "bottoms", catLabel: "Bottoms", badge: "hot", desc: "Parachute nylon feel. Cinched ankles. Main-character pants.", img: u("photo-1506629082955-511b1aa784c1") },
  { id: "coach-jacket", name: "Coach Jacket", price: 3199, category: "outerwear", catLabel: "Outerwear", badge: null, desc: "Water-resistant coach jacket. Snap buttons. Light layer king.", img: u("photo-1487222477894-8943e31ef7b2") },
  { id: "crossbody", name: "Crossbody Bag", price: 1499, category: "accessories", catLabel: "Accessories", badge: "new", desc: "Compact crossbody. Adjustable strap. Phone, wallet, keys done.", img: u("photo-1548036328-c9fa89d128fa") },
  { id: "retro-tee", name: "Retro Wave Tee", price: 1299, category: "tees", catLabel: "Graphic Tee", badge: null, desc: "Retro wave graphic. Soft washed cotton. Y2K without trying too hard.", img: u("photo-1503342217505-b0a15ec3261c") },
  { id: "fleece-hoodie", name: "Fleece Hoodie", price: 2499, category: "hoodies", catLabel: "Heavyweight", badge: null, desc: "Plush fleece inside. Ribbed hem. Winter daily driver.", img: u("photo-1556821840-3a63f95609a7") },
  { id: "joggers", name: "Tapered Joggers", price: 1699, category: "bottoms", catLabel: "Bottoms", badge: null, desc: "Tapered joggers. Soft stretch. Travel and chill uniform.", img: u("photo-1552902865-b72c031ac5ea") },
  { id: "windbreaker", name: "Windbreaker", price: 2799, category: "outerwear", catLabel: "Outerwear", badge: "limited", desc: "Packable windbreaker. Neon zip detail. Monsoon-ready shell.", img: u("photo-1544923246-77307dd28ed4") },
  { id: "chain-necklace", name: "Chain Necklace", price: 799, category: "accessories", catLabel: "Accessories", badge: null, desc: "Stainless chain. Water-resistant. Stack or wear solo.", img: u("photo-1611652022419-a9419f74343d") },
  { id: "heavy-tee", name: "Heavyweight Blank Tee", price: 999, category: "tees", catLabel: "Graphic Tee", badge: null, desc: "Blank heavyweight tee. Premium blank for pure fit flex.", img: u("photo-1521572163474-6864f9cf17ab") },
  { id: "sherpa-hoodie", name: "Sherpa Lined Hoodie", price: 3299, category: "hoodies", catLabel: "Heavyweight", badge: "hot", desc: "Sherpa-lined warmth. Serious winter piece. Looks premium.", img: u("photo-1578768076945-8d57054b5ba5") },
  { id: "carpenter-pants", name: "Carpenter Pants", price: 2299, category: "bottoms", catLabel: "Bottoms", badge: "new", desc: "Carpenter utility pants. Loop details. Workwear meets street.", img: u("photo-1624378439575-d8705ad7ae80") },
  { id: "leather-jacket", name: "Faux Leather Jacket", price: 4499, category: "outerwear", catLabel: "Outerwear", badge: "limited", desc: "Faux leather biker cut. Soft lining. Night-out uniform.", img: u("photo-1521223890158-f9f7c3d5d504") },
  { id: "sunglasses", name: "Void Sunglasses", price: 1299, category: "accessories", catLabel: "Accessories", badge: null, desc: "UV-protected shades. Matte frame. Instant main-character energy.", img: u("photo-1511499767150-a48a237ac008") },
  { id: "stripe-tee", name: "Stripe Oversized Tee", price: 1199, category: "tees", catLabel: "Graphic Tee", badge: null, desc: "Horizontal stripe tee. Soft jersey. Easy weekend fit.", img: u("photo-1562157873-818bc0726f68") },
  { id: "halfzip-hoodie", name: "Half-Zip Hoodie", price: 2599, category: "hoodies", catLabel: "Heavyweight", badge: "new", desc: "Half-zip pullover. Clean collar. Smart-casual street hybrid.", img: u("photo-1620799140408-edc6dcb6d633") },
  { id: "pleated-pants", name: "Pleated Wide Pants", price: 2499, category: "bottoms", catLabel: "Bottoms", badge: null, desc: "Pleated wide pants. Flowy drape. Elevated street look.", img: u("photo-1473966968600-fa801b869a1a") },
  { id: "utility-vest", name: "Utility Vest", price: 2699, category: "outerwear", catLabel: "Outerwear", badge: "hot", desc: "Multi-pocket utility vest. Layer over hoodies and tees.", img: u("photo-1434389677669-e08b4cac3105") },
  { id: "ring-set", name: "Ring Set", price: 599, category: "accessories", catLabel: "Accessories", badge: null, desc: "3-piece ring set. Mixed finishes. Stack for detail.", img: u("photo-1605100804763-247f67b3557e") },
  { id: "desi-tee", name: "Desi Drip Tee", price: 1299, category: "tees", catLabel: "Graphic Tee", badge: "new", desc: "India-inspired graphic tee. Soft cotton. Made for desi Gen-Z energy.", img: u("photo-1576566588028-4147f3842f27") },
  { id: "mumbai-hoodie", name: "Mumbai Nights Hoodie", price: 2599, category: "hoodies", catLabel: "Heavyweight", badge: "hot", desc: "City-night graphic hoodie. Heavy fleece. Built for late Mumbai runs.", img: u("photo-1515886657613-9f3515b0c78f") },
  { id: "delhi-cargo", name: "Delhi Cargo Pants", price: 1999, category: "bottoms", catLabel: "Bottoms", badge: null, desc: "City cargo pants. Tough fabric. Pocket space for the whole day.", img: u("photo-1542272604-787c3835535d") },
  { id: "genz-cap", name: "GenZ Snapback", price: 849, category: "accessories", catLabel: "Accessories", badge: "new", desc: "Flat-brim snapback. Bold VOID mark. Instant head-to-toe finish.", img: u("photo-1521369909029-2afed882baee") },
];

export function productCode(id: string) {
  const i = PRODUCTS.findIndex((p) => p.id === id);
  return "VD-" + String(1010 + (i < 0 ? 0 : i));
}

export const CATEGORIES: { id: ProductCategory | "all"; label: string }[] = [
  { id: "all", label: "All" },
  { id: "tees", label: "Tees" },
  { id: "hoodies", label: "Hoodies" },
  { id: "bottoms", label: "Bottoms" },
  { id: "outerwear", label: "Outerwear" },
  { id: "accessories", label: "Accessories" },
];

export const SHIPPING = 99;
