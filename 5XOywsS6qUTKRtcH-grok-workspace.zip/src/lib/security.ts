const TAGS = /<\/?[^>]+>/g;
const CONTROL = /[\u0000-\u001F\u007F]/g;
const JS_URL = /^\s*(javascript|data|vbscript):/i;

export function cleanText(value: string, max = 160) {
  const out = value.replace(TAGS, "").replace(CONTROL, "").trim().slice(0, max);
  if (JS_URL.test(out)) return "";
  return out;
}

export function digitsIndiaMobile(value: string) {
  let d = value.replace(/\D/g, "");
  if (d.startsWith("91") && d.length >= 12) d = d.slice(2);
  if (d.startsWith("0") && d.length === 11) d = d.slice(1);
  return d.slice(0, 10);
}

export function isIndianMobile(value: string) {
  return /^[6-9]\d{9}$/.test(digitsIndiaMobile(value));
}

export function isIndianPincode(value: string) {
  return /^[1-9][0-9]{5}$/.test(value.replace(/\s/g, ""));
}

export function isEmail(value: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value) && value.length < 120 && !JS_URL.test(value);
}

export function isRazorpayKey(value: string) {
  return /^rzp_(test|live)_[A-Za-z0-9]{8,40}$/.test(value.trim());
}

export function tooSoon(key: string, ms = 8000) {
  try {
    const last = Number(sessionStorage.getItem(key) || "0");
    if (Date.now() - last < ms) return true;
    sessionStorage.setItem(key, String(Date.now()));
    return false;
  } catch {
    return false;
  }
}
