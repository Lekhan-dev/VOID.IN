export const SOCIALS = [
  { id: "ig", label: "Instagram", href: "https://instagram.com/void.wear", handle: "@void.wear" },
  { id: "x", label: "X", href: "https://x.com/voidwear", handle: "@voidwear" },
  { id: "fb", label: "Facebook", href: "https://facebook.com/voidwear", handle: "VOID" },
  { id: "yt", label: "YouTube", href: "https://youtube.com/@voidwear", handle: "@voidwear" },
] as const;

export const IG_TAG = "@void.wear";
