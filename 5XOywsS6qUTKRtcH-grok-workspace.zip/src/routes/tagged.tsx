import { createFileRoute } from "@tanstack/react-router";
import { TaggedGrid } from "@/components/tagged-grid";
import { IG_TAG, SOCIALS } from "@/lib/socials";

export const Route = createFileRoute("/tagged")({ component: TaggedPage });

function TaggedPage() {
  const ig = SOCIALS.find((s) => s.id === "ig")!;
  return (
    <section className="mx-auto w-[min(1200px,92%)] py-8">
      <p className="text-xs uppercase tracking-[0.2em] text-muted">Community</p>
      <h1 className="mt-2 font-display text-4xl font-bold">Tagged</h1>
      <p className="mt-2 max-w-lg text-muted">
        Buy VOID. Post the fit. Tag {IG_TAG} on Instagram. We pick a few looks and put them here.
      </p>
      <a
        href={ig.href}
        target="_blank"
        rel="noopener noreferrer"
        className="cut-btn mt-5 inline-flex min-h-11 items-center bg-primary px-5 text-sm font-semibold text-[#070707]"
      >
        Tag {IG_TAG}
      </a>
      <div className="mt-8">
        <TaggedGrid />
      </div>
    </section>
  );
}
