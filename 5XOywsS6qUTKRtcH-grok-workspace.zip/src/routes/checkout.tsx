import { createFileRoute, Link } from "@tanstack/react-router";
import { CreditCard, Landmark, Minus, Plus, ShieldCheck, Smartphone, Trash2, Wallet } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { ProductPlaceholder } from "@/components/product-card";
import { useCurrentUser } from "@/lib/auth/use-current-user";
import { cartTotals, useCart } from "@/lib/cart";
import { loadRazorpay } from "@/lib/razorpay";
import { useOps, stockOf, nextOrderCode } from "@/lib/ops";
import { productCode } from "@/lib/products";
import { playCheckoutSound } from "@/lib/sfx";
import { cleanText, digitsIndiaMobile, isIndianMobile, isIndianPincode, isRazorpayKey, tooSoon } from "@/lib/security";
import { inr } from "@/lib/utils";

export const Route = createFileRoute("/checkout")({ component: Checkout });

type Receipt = {
  orderId: string;
  extra: string;
  name: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  pincode: string;
  items: { name: string; qty: number; price: number; code: string }[];
  total: number;
};

const METHODS = [
  { id: "upi", icon: Smartphone, label: "UPI", hint: "GPay · PhonePe · Paytm" },
  { id: "card", icon: CreditCard, label: "Cards", hint: "Visa · Mastercard · RuPay" },
  { id: "netbanking", icon: Landmark, label: "NetBanking", hint: "All major banks" },
  { id: "wallet", icon: Wallet, label: "Wallets", hint: "Paytm · Amazon Pay" },
] as const;

function Checkout() {
  const user = useCurrentUser();
  let localMe = false;
  try {
    localMe = Boolean(sessionStorage.getItem("void_me"));
  } catch {
    /* ignore */
  }
  const signedIn = Boolean(user) || localMe;
  const items = useCart((s) => s.items);
  const setQty = useCart((s) => s.setQty);
  const remove = useCart((s) => s.remove);
  const clear = useCart((s) => s.clear);
  const totals = cartTotals(items);
  const [key, setKey] = useState("");
  const [loading, setLoading] = useState(false);
  const [ready, setReady] = useState(false);
  const [payMethod, setPayMethod] = useState<(typeof METHODS)[number]["id"]>("upi");
  const [receipt, setReceipt] = useState<Receipt | null>(null);
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    address: "",
    city: "",
    pincode: "",
    state: "",
  });

  useEffect(() => {
    const saved = localStorage.getItem("void_rzp_key");
    if (saved) setKey(saved);
    void loadRazorpay().then(setReady);
  }, []);

  function complete(extra: string) {
    const orderId = nextOrderCode(useOps.getState().orders.map((o) => o.id));
    const rec: Receipt = {
      orderId,
      extra,
      name: cleanText(form.name, 80),
      phone: "+91" + digitsIndiaMobile(form.phone),
      address: cleanText(form.address, 200),
      city: cleanText(form.city, 80),
      state: cleanText(form.state, 40),
      pincode: cleanText(form.pincode, 6),
      items: items.map((i) => ({ name: i.name, qty: i.qty, price: i.price, code: productCode(i.id) })),
      total: totals.total,
    };
    useOps.getState().placeOrder({
      id: orderId,
      createdAt: Date.now(),
      name: rec.name,
      phone: rec.phone,
      address: rec.address,
      city: rec.city,
      state: rec.state,
      pincode: rec.pincode,
      items: items.map((i) => ({
        id: i.id,
        code: productCode(i.id),
        name: i.name,
        qty: i.qty,
        price: i.price,
      })),
      total: rec.total,
      payment: extra,
    });
    playCheckoutSound();
    setReceipt(rec);
    clear();
    toast.success("Order " + orderId);
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (items.length === 0) {
      toast.error("Cart is empty");
      return;
    }
    const name = cleanText(form.name, 80);
    const email = cleanText(form.email, 120);
    const phone = digitsIndiaMobile(form.phone);
    const address = cleanText(form.address, 200);
    const city = cleanText(form.city, 80);
    const pincode = cleanText(form.pincode, 6).replace(/\D/g, "");
    const state = cleanText(form.state, 40);
    if (!signedIn) {
      toast.error("Sign in to checkout");
      return;
    }
    if (!name || !phone || !address || !city || !pincode || !state) {
      toast.error("Fill all shipping fields");
      return;
    }
    if (!isIndianMobile(phone)) {
      toast.error("Enter a valid 10-digit Indian mobile starting 6–9");
      return;
    }
    if (!isIndianPincode(pincode)) {
      toast.error("Enter a valid 6-digit Indian PIN code");
      return;
    }
    const stock = useOps.getState().stock;
    const missing = items.find((i) => i.qty > stockOf(stock, i.id));
    if (missing) {
      toast.error(missing.name + " is low on stock. Reduce qty.");
      return;
    }
    if (tooSoon("void_pay_at", 4000)) {
      toast.error("Wait a moment, then try again");
      return;
    }
    const k = cleanText(key || localStorage.getItem("void_rzp_key") || "", 60);
    if (!isRazorpayKey(k)) {
      toast.error("Add a valid Razorpay Key ID (rzp_test_ or rzp_live_)");
      return;
    }
    localStorage.setItem("void_rzp_key", k);
    setLoading(true);
    const ok = await loadRazorpay();
    if (!ok || !window.Razorpay) {
      setLoading(false);
      toast.error("Razorpay failed to load. Check internet.");
      return;
    }
    const paise = Math.round(totals.total * 100);
    if (paise < 100) {
      setLoading(false);
      toast.error("Amount too low");
      return;
    }
    const itemNote = items
      .map((i) => i.name + " x" + i.qty)
      .join(", ")
      .slice(0, 180);
    const rzp = new window.Razorpay({
      key: k,
      amount: paise,
      currency: "INR",
      name: "VOID",
      description: "VOID order · " + items.length + " item(s)",
      prefill: {
        name,
        email,
        contact: phone,
      },
      notes: {
        brand: "VOID",
        items: itemNote,
        city,
        pincode,
        state,
        pay_method: payMethod,
      },
      theme: { color: "#d6ff3f" },
      method: {
        upi: payMethod === "upi",
        card: payMethod === "card",
        netbanking: payMethod === "netbanking",
        wallet: payMethod === "wallet",
      },
      retry: { enabled: true, max_count: 3 },
      timeout: 600,
      remember_customer: true,
      modal: {
        backdropclose: false,
        escape: true,
        confirm_close: true,
        ondismiss: () => {
          setLoading(false);
          toast.message("Payment cancelled");
        },
      },
      handler: (response: { razorpay_payment_id?: string }) => {
        setLoading(false);
        complete("Paid via Razorpay · " + (response.razorpay_payment_id || "ok"));
      },
    });
    rzp.on("payment.failed", (resp) => {
      setLoading(false);
      toast.error(resp.error?.description || resp.error?.reason || "Payment failed");
    });
    rzp.open();
  }

  if (!signedIn) {
    return (
      <section className="mx-auto w-[min(520px,92%)] py-8 text-center">
        <p className="text-xs uppercase tracking-[0.2em] text-muted">Checkout</p>
        <h1 className="mt-2 font-display text-4xl font-bold">Sign in first</h1>
        <p className="mt-2 text-muted">
          India only. Create an account or sign in to pay. No guest checkout.
        </p>
        <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:justify-center">
          <Link
            to="/login"
            search={{ mode: "signup", next: "/checkout" }}
            className="cut-btn inline-flex min-h-12 items-center justify-center bg-primary px-6 font-semibold text-[#070707]"
          >
            Sign up
          </Link>
          <Link
            to="/login"
            search={{ next: "/checkout" }}
            className="inline-flex min-h-12 items-center justify-center rounded-full border border-border px-6 font-semibold"
          >
            Sign in
          </Link>
        </div>
      </section>
    );
  }

  if (receipt) {
    return (
      <section className="mx-auto w-[min(720px,92%)] py-12 text-center">
        <div className="mx-auto grid size-16 place-items-center rounded-full bg-primary text-2xl font-bold text-[#070707]">
          ✓
        </div>
        <h1 className="mt-4 font-display text-3xl font-bold">Paid with Razorpay</h1>
        <p className="mt-2 text-muted">Your order code — same one staff uses to pack it.</p>
        <p className="mt-3 font-mono text-2xl font-bold text-primary">{receipt.orderId}</p>
        <p className="mt-1 text-xs text-muted">{receipt.extra}</p>
        <div className="mt-6 rounded-lg border border-border bg-surface p-4 text-left text-sm text-muted">
          {receipt.name && (
            <p>
              <span className="font-semibold text-fg">Ship to</span>
              <br />
              {receipt.name}
              <br />
              {receipt.phone}
              <br />
              {receipt.address}
              {receipt.city ? `, ${receipt.city}` : ""} {receipt.pincode}
            </p>
          )}
          <p className="mt-3 font-semibold text-fg">Items</p>
          {receipt.items.map((i) => (
            <p key={i.name}>
              {i.code} · {i.name} × {i.qty} — {inr(i.price * i.qty)}
            </p>
          ))}
          <p className="mt-2 font-bold text-primary">Total: {inr(receipt.total)}</p>
        </div>
        <div className="mt-8 flex flex-col items-center gap-3 sm:flex-row sm:justify-center">
          <Link
            to="/track"
            search={{ id: receipt.orderId }}
            className="cut-btn inline-flex min-h-12 items-center bg-primary px-6 font-semibold text-[#070707]"
          >
            Track this order
          </Link>
          <Link
            to="/shop"
            className="inline-flex min-h-12 items-center rounded-full border border-border px-6 font-semibold transition-transform duration-150 active:scale-[0.96]"
          >
            Keep shopping
          </Link>
        </div>
      </section>
    );
  }

  return (
    <section className="mx-auto grid w-[min(1200px,92%)] gap-8 py-6 lg:grid-cols-[1.1fr_0.9fr]">
      <div>
        <p className="text-xs uppercase tracking-[0.2em] text-muted">Checkout</p>
        <h1 className="mt-2 font-display text-4xl font-bold">Your Order</h1>
        {items.length === 0 ? (
          <p className="mt-8 text-muted">
            Cart is empty.{" "}
            <Link to="/shop" className="text-primary">
              Shop the drop
            </Link>
          </p>
        ) : (
          <ul className="mt-6 space-y-3">
              {items.map((i) => (
                <li
                  key={i.id}
                  className="flex gap-3 rounded-lg border border-border bg-surface p-3"
                >
                  <div className="size-20 overflow-hidden rounded-md">
                    <ProductPlaceholder name={i.name} />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="font-medium">{i.name}</p>
                    <p className="text-sm tabular-nums text-primary">{inr(i.price)}</p>
                    <div className="mt-2 flex items-center gap-2">
                      <button
                        type="button"
                        className="grid size-9 place-items-center rounded-md border border-border transition-transform duration-150 active:scale-[0.96]"
                        onClick={() => setQty(i.id, i.qty - 1)}
                        aria-label="Decrease"
                      >
                        <Minus className="size-3" />
                      </button>
                      <span className="w-6 text-center tabular-nums">{i.qty}</span>
                      <button
                        type="button"
                        className="grid size-9 place-items-center rounded-md border border-border transition-transform duration-150 active:scale-[0.96]"
                        onClick={() => setQty(i.id, i.qty + 1)}
                        aria-label="Increase"
                      >
                        <Plus className="size-3" />
                      </button>
                      <button
                        type="button"
                        className="ml-auto grid size-9 place-items-center text-muted transition-colors hover:text-hot"
                        onClick={() => remove(i.id)}
                        aria-label="Remove"
                      >
                        <Trash2 className="size-4" />
                      </button>
                    </div>
                  </div>
                </li>
              ))}
          </ul>
        )}
      </div>

      <aside className="h-fit rounded-lg border border-border bg-surface p-5">
        <h2 className="font-display text-xl font-bold">Pay with Razorpay</h2>
        <div className="mt-4 space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-muted">Subtotal</span>
            <span className="tabular-nums">{inr(totals.subtotal)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted">Shipping</span>
            <span className="tabular-nums">{totals.shipping ? inr(totals.shipping) : "—"}</span>
          </div>
          <div className="flex justify-between border-t border-border pt-2 font-semibold">
            <span>Total</span>
            <span className="tabular-nums text-primary">{inr(totals.total)}</span>
          </div>
        </div>

        <form className="mt-6 space-y-3" onSubmit={onSubmit}>
          <p className="text-xs font-semibold uppercase tracking-widest text-muted">Shipping · India only</p>
          <input
            required
            maxLength={80}
            autoComplete="name"
            placeholder="Full name"
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            className="min-h-11 w-full rounded-md border border-border bg-bg px-3 text-sm"
          />
          <input
            type="email"
            maxLength={80}
            autoComplete="email"
            placeholder="Email"
            value={form.email}
            onChange={(e) => setForm({ ...form, email: e.target.value })}
            className="min-h-11 w-full rounded-md border border-border bg-bg px-3 text-sm"
          />
          <div className="flex overflow-hidden rounded-md border border-border">
            <span className="grid min-h-11 place-items-center bg-elevated px-3 text-sm font-semibold">+91</span>
            <input
              required
              inputMode="numeric"
              autoComplete="tel"
              maxLength={10}
              placeholder="10-digit mobile"
              value={form.phone}
              onChange={(e) => setForm({ ...form, phone: digitsIndiaMobile(e.target.value) })}
              className="min-h-11 w-full bg-bg px-3 text-sm outline-none"
            />
          </div>
          <input
            required
            maxLength={200}
            autoComplete="street-address"
            placeholder="Address"
            value={form.address}
            onChange={(e) => setForm({ ...form, address: e.target.value })}
            className="min-h-11 w-full rounded-md border border-border bg-bg px-3 text-sm"
          />
          <div className="grid grid-cols-2 gap-2">
            <input
              required
              maxLength={80}
              placeholder="City"
              value={form.city}
              onChange={(e) => setForm({ ...form, city: e.target.value })}
              className="min-h-11 w-full rounded-md border border-border bg-bg px-3 text-sm"
            />
            <input
              required
              inputMode="numeric"
              autoComplete="postal-code"
              maxLength={6}
              placeholder="PIN (6 digits)"
              value={form.pincode}
              onChange={(e) => setForm({ ...form, pincode: e.target.value.replace(/\D/g, "").slice(0, 6) })}
              className="min-h-11 w-full rounded-md border border-border bg-bg px-3 text-sm"
            />
          </div>
          <select
            value={form.state}
            onChange={(e) => setForm({ ...form, state: e.target.value })}
            className="min-h-11 w-full rounded-md border border-border bg-bg px-3 text-sm outline-none transition-[border-color] duration-200 focus:border-primary"
          >
            <option value="">Select state</option>
            {[
              "Andhra Pradesh",
              "Assam",
              "Bihar",
              "Delhi",
              "Goa",
              "Gujarat",
              "Haryana",
              "Himachal Pradesh",
              "Jammu and Kashmir",
              "Jharkhand",
              "Karnataka",
              "Kerala",
              "Madhya Pradesh",
              "Maharashtra",
              "Odisha",
              "Punjab",
              "Rajasthan",
              "Tamil Nadu",
              "Telangana",
              "Uttar Pradesh",
              "Uttarakhand",
              "West Bengal",
            ].map((s) => (
              <option key={s}>{s}</option>
            ))}
          </select>

          <p className="pt-2 text-xs font-semibold uppercase tracking-widest text-muted">Pay with</p>
          <div className="flex items-center justify-between rounded-md border border-primary bg-primary-dim px-3 py-3 text-sm">
            <span className="inline-flex items-center gap-2 font-medium">
              <ShieldCheck className="size-4 text-primary" />
              Pay now
            </span>
            <span className="font-bold tabular-nums text-primary">{inr(totals.total)}</span>
          </div>
          <div className="grid grid-cols-2 gap-2">
            {METHODS.map((m) => (
              <button
                key={m.id}
                type="button"
                onClick={() => setPayMethod(m.id)}
                className={
                  "rounded-lg border bg-bg p-3 text-left transition " +
                  (payMethod === m.id
                    ? "border-primary shadow-[0_0_0_1px_var(--color-primary)]"
                    : "border-border hover:border-primary")
                }
              >
                <m.icon className="size-4 text-primary" />
                <p className="mt-1 text-sm font-semibold">{m.label}</p>
                <p className="text-[11px] text-muted">{m.hint}</p>
              </button>
            ))}
          </div>
          <details className="rounded-md border border-dashed border-border p-3 text-xs text-muted">
            <summary className="cursor-pointer font-semibold">Store owner: Razorpay Key ID</summary>
            <p className="mt-2">
              Paste Key ID only (rzp_test_ or rzp_live_). Never paste the Secret.
            </p>
            <input
              value={key}
              onChange={(e) => setKey(e.target.value)}
              placeholder="rzp_test_..."
              maxLength={60}
              autoComplete="off"
              spellCheck={false}
              className="mt-2 min-h-10 w-full rounded-md border border-border bg-bg px-3"
            />
            <p className="mt-2">
              Test card: 4111 1111 1111 1111 · any future expiry · any CVV
            </p>
          </details>
          <button
            type="submit"
            disabled={loading || items.length === 0}
            className="cut-btn flex min-h-12 w-full items-center justify-center bg-primary font-semibold text-[#070707] disabled:opacity-60"
          >
            {loading ? "Opening Razorpay…" : "Pay with " + METHODS.find((m) => m.id === payMethod)?.label}
          </button>
          <p className="text-center text-[11px] text-muted">
            {ready ? "Razorpay ready. " : "Loading Razorpay… "}
            Encrypted checkout. VOID never stores card details.
          </p>
        </form>
      </aside>
    </section>
  );
}
