import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { CATEGORY_TILES, CategoryCard } from "@/components/category-card";
import { TaggedGrid } from "@/components/tagged-grid";
import { IG_TAG, SOCIALS } from "@/lib/socials";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <>
      <section className="slash relative overflow-hidden">
        <div className="mx-auto flex w-[min(1200px,92%)] flex-col justify-center py-8">
          <p className="wipe mb-5 inline-flex w-fit items-center gap-2 rounded-full border border-border bg-surface px-3 py-1 text-xs font-medium uppercase tracking-widest text-muted">
            <span className="size-1.5 animate-pulse rounded-full bg-primary" />
            New drop live
          </p>
          <h1 className="cut-title font-display text-[clamp(3rem,12vw,7rem)] font-extrabold leading-[0.9] tracking-tight">
            WEAR
            <br />
            <span className="text-primary">THE</span> SHIFT
          </h1>
          <p className="mt-6 max-w-md text-muted">
            Streetwear for Indian Gen-Z. Pieces by Lekhan and independent makers.
            <br />
            Built in India. Ships in India only.
          </p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <Link
              to="/shop"
              className="cut-btn inline-flex min-h-12 items-center justify-center gap-2 bg-primary px-6 font-semibold"
            >
              Shop the Drop
              <ArrowRight className="size-4" />
            </Link>
            <a
              href="#story"
              className="inline-flex min-h-12 items-center justify-center rounded-full border border-border px-6 font-semibold"
            >
              Our Story
            </a>
          </div>
          <div className="mt-6 flex gap-8 text-sm">
            <div>
              <p className="text-[10px] uppercase tracking-widest text-muted">Founded by</p>
              <p className="font-semibold">Lekhan</p>
            </div>
            <div>
              <p className="text-[10px] uppercase tracking-widest text-muted">Est.</p>
              <p className="font-semibold">2026</p>
            </div>
          </div>
        </div>
      </section>

      <div className="ticker" aria-hidden="true">
        <div className="ticker-track">
          <span>Drop live</span>
          <span>Lekhan</span>
          <span>Guest makers</span>
          <span>India streets</span>
          <span>No returns</span>
          <span>Ready to shift</span>
          <span>Drop live</span>
          <span>Lekhan</span>
          <span>Guest makers</span>
          <span>India streets</span>
          <span>No returns</span>
          <span>Ready to shift</span>
        </div>
      </div>

      <section className="relative border-t border-border py-10">
        <div className="mx-auto w-[min(1200px,92%)]">
          <p className="text-xs uppercase tracking-[0.2em] text-muted">Shop</p>
          <h2 className="mt-2 font-display text-3xl font-bold md:text-4xl">Categories</h2>
          <div className="cat-grid mt-4 grid gap-3 md:grid-cols-2">
            {CATEGORY_TILES.map((c) => (
              <CategoryCard key={c.cat} {...c} />
            ))}
          </div>
          <div className="mt-6 flex justify-center">
            <Link
              to="/shop"
              className="cut-btn inline-flex min-h-12 items-center justify-center gap-2 bg-primary px-10 font-semibold"
            >
              Shop Now
              <ArrowRight className="size-4" />
            </Link>
          </div>
        </div>
      </section>

      <section id="tagged" className="relative border-t border-border py-10">
        <div className="mx-auto w-[min(1200px,92%)]">
          <p className="text-xs uppercase tracking-[0.2em] text-muted">Instagram</p>
          <h2 className="mt-2 font-display text-3xl font-bold md:text-4xl">Tagged</h2>
          <p className="mt-2 max-w-lg text-muted">
            Wear it. Tag {IG_TAG}. We pick a few people and post the fit here.
          </p>
          <div className="mt-6">
            <TaggedGrid />
          </div>
          <div className="mt-6 flex flex-wrap gap-3">
            <a
              href={SOCIALS[0].href}
              target="_blank"
              rel="noopener noreferrer"
              className="cut-btn inline-flex min-h-12 items-center justify-center bg-primary px-6 font-semibold text-[#070707]"
            >
              Tag {IG_TAG}
            </a>
            <Link
              to="/tagged"
              className="inline-flex min-h-12 items-center justify-center rounded-full border border-border px-6 font-semibold"
            >
              See all picks
            </Link>
          </div>
        </div>
      </section>

      <section id="story" className="relative border-y border-border bg-elevated py-10">
        <div className="mx-auto grid w-[min(1200px,92%)] items-center gap-10 md:grid-cols-[1.2fr_0.8fr]">
          <div>
            <p className="text-xs uppercase tracking-[0.2em] text-muted">Origin</p>
            <h2 className="mt-2 font-display text-4xl font-bold">
              Founded by
              <br />
              <span className="text-primary">Lekhan</span>
            </h2>
            <p className="mt-4 max-w-md text-muted">
              VOID is Lekhan’s house — and a shelf for other makers too. Clothes designed by Lekhan,
              plus drops from independent designers we actually believe in. No fake collabs. No
              random restocks.
            </p>
            <p className="mt-3 max-w-md text-muted">
              Limited runs. Dropped when they’re ready — not when a calendar says so.
            </p>
          </div>
          <div className="rounded-lg border border-border bg-surface p-8 text-center">
            <div className="mx-auto grid size-24 place-items-center rounded-full border-2 border-border bg-bg font-display text-4xl font-extrabold text-primary">
              L
            </div>
            <h3 className="mt-5 font-display text-2xl font-bold">Lekhan</h3>
            <p className="text-sm text-muted">Founder & Creative Director</p>
            <p className="mt-4 italic text-muted">“Clothes should say something before you do.”</p>
          </div>
        </div>
      </section>
    </>
  );
}
