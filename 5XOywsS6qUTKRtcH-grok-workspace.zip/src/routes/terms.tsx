import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/terms")({ component: Terms });

function Terms() {
  return (
    <article className="mx-auto w-[min(720px,92%)] py-12">
      <p className="text-xs uppercase tracking-[0.2em] text-muted">Legal</p>
      <h1 className="mt-2 font-display text-4xl font-bold">Terms of Service</h1>
      <p className="mt-2 text-sm text-muted">Last updated: September 2026</p>
      <div className="mt-8 space-y-4 text-muted">
        <h2 className="font-display text-xl font-bold text-fg">1. About VOID</h2>
        <p>
          VOID is a streetwear house founded by Lekhan. The shop sells pieces designed by Lekhan and
          by independent makers. These Terms govern use of the VOID website, the shop, checkout,
          order tracking, and any related services.
        </p>
        <h2 className="font-display text-xl font-bold text-fg">2. Eligibility</h2>
        <p>
          You must be able to form a binding contract under Indian law. If you are under 18, a
          parent or guardian must place the order.
        </p>
        <h2 className="font-display text-xl font-bold text-fg">3. Orders and payment</h2>
        <p>
          An order is an offer to buy. VOID may accept or refuse an order (wrong price, stock,
          suspected fraud). Payment is collected by Razorpay (UPI, cards, netbanking, wallets). Card
          data never touches VOID systems. No cash on delivery.
        </p>
        <h2 className="font-display text-xl font-bold text-fg">4. No cancellations</h2>
        <p>
          Once payment succeeds, the order cannot be cancelled. Staff will not cancel paid orders.
          Choose size, address, and payment method carefully before you pay.
        </p>
        <h2 className="font-display text-xl font-bold text-fg">5. No returns / no refunds</h2>
        <p>
          All sales are final. VOID does not accept returns, exchanges, or refunds on streetwear
          drops, including wrong size, change of mind, or buyer’s remorse. If an item arrives
          damaged in transit, write to us with photos within 48 hours of delivery and we will review
          it case by case. That is not a guaranteed replacement.
        </p>
        <h2 className="font-display text-xl font-bold text-fg">6. Shipping</h2>
        <p>
          Delivery timelines are estimates. Track status on the Track page (Ordered → Packing →
          Shipped → Delivered). Risk passes to you on handover to the courier.
        </p>
        <h2 className="font-display text-xl font-bold text-fg">7. Stock</h2>
        <p>
          Inventory on the shop is live. Sold-out items cannot be purchased. We may limit quantity
          per customer.
        </p>
        <h2 className="font-display text-xl font-bold text-fg">8. Content and IP</h2>
        <p>
          Logos, graphics, copy, and product names are owned by VOID / Lekhan. Do not copy, scrape,
          or resell site content without written permission.
        </p>
        <h2 className="font-display text-xl font-bold text-fg">9. Acceptable use</h2>
        <p>
          No fraud, chargeback abuse, scraping, hacking, or interfering with checkout, staff tools,
          or other customers.
        </p>
        <h2 className="font-display text-xl font-bold text-fg">10. Limitation of liability</h2>
        <p>
          VOID is not liable for indirect or consequential loss. Our total liability for a product
          is limited to the amount you paid for that product.
        </p>
        <h2 className="font-display text-xl font-bold text-fg">11. Law</h2>
        <p>These Terms are governed by the laws of India. Courts in India have jurisdiction.</p>
        <p>Founded by Lekhan.</p>
      </div>
    </article>
  );
}
