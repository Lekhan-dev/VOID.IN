import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/privacy")({ component: Privacy });

function Privacy() {
  return (
    <article className="mx-auto w-[min(720px,92%)] py-12">
      <p className="text-xs uppercase tracking-[0.2em] text-muted">Legal</p>
      <h1 className="mt-2 font-display text-4xl font-bold">Privacy Policy</h1>
      <p className="mt-2 text-sm text-muted">Last updated: September 2026</p>
      <div className="mt-8 space-y-4 text-muted">
        <p>
          VOID is a streetwear house founded by Lekhan. We sell pieces by Lekhan and independent
          makers. This policy explains what we collect, why, and how you can control it.
        </p>
        <h2 className="font-display text-xl font-bold text-fg">What we collect</h2>
        <p>
          Checkout: name, email, phone, address, city, state, PIN. Cart contents. Order ID and
          payment status from Razorpay. Cookie choice. Staff PIN is never stored on the customer
          shop.
        </p>
        <h2 className="font-display text-xl font-bold text-fg">What we do not collect</h2>
        <p>
          We do not store card numbers, CVV, UPI PINs, or netbanking passwords. Razorpay processes
          those. We do not sell personal data. We do not run ad pixels or third-party analytics
          cookies.
        </p>
        <h2 id="cookies" className="scroll-mt-24 font-display text-xl font-bold text-fg">
          Cookies and local storage
        </h2>
        <p>
          On first visit a banner asks Accept or Necessary only. Your choice is saved as
          void_cookie_choice.
        </p>
        <p>
          <span className="text-fg">Necessary:</span> cart (void_cart), orders and inventory for
          this browser (void_ops), Razorpay Key ID for the store owner (void_rzp_key), cookie
          preference. These keep shop, checkout, and tracking working.
        </p>
        <p>
          <span className="text-fg">Accept:</span> same as necessary today. VOID does not add
          marketing cookies.
        </p>
        <p>
          Session storage may keep a staff-desk unlock flag on the worker device only. Clearing
          site data resets the cart, cookie banner, and local orders on that browser.
        </p>
        <h2 className="font-display text-xl font-bold text-fg">Why we use data</h2>
        <p>
          To take payment, pack and ship, show tracking, prevent fraud, and improve the shop. Legal
          bases: contract (your order) and legitimate interest (security, stock).
        </p>
        <h2 className="font-display text-xl font-bold text-fg">Sharing</h2>
        <p>
          Razorpay (payments). Courier / delivery partners (name, phone, address). We do not share
          data with advertisers.
        </p>
        <h2 className="font-display text-xl font-bold text-fg">Retention</h2>
        <p>
          Order details stay as long as needed for shipping, tax, and dispute handling. Browser
          storage stays until you clear it.
        </p>
        <h2 className="font-display text-xl font-bold text-fg">Your choices</h2>
        <p>
          You can refuse non-necessary cookies, clear site data, or ask what we hold on an order by
          quoting your order ID. Do not send card details over email or chat.
        </p>
        <h2 className="font-display text-xl font-bold text-fg">Security</h2>
        <p>
          HTTPS, nosniff and related headers, checkout sanitization, rate-limits on pay and staff
          PIN. No system is unhackable. Use a strong Razorpay live key only on the owner device.
        </p>
        <p>Founded by Lekhan.</p>
      </div>
    </article>
  );
}
