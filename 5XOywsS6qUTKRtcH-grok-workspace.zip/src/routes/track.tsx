import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { normStatus, useOps, type OpsOrder, type OrderStatus } from "@/lib/ops";
import { productCode } from "@/lib/products";
import { inr } from "@/lib/utils";

type TrackSearch = { id?: string };

export const Route = createFileRoute("/track")({
  validateSearch: (s: Record<string, unknown>): TrackSearch => ({
    id: typeof s.id === "string" ? s.id : undefined,
  }),
  component: Track,
});

const STEPS: { id: OrderStatus; label: string; copy: string }[] = [
  { id: "new", label: "Ordered", copy: "Payment in. We have the drop." },
  { id: "packing", label: "Packing", copy: "Your piece is being packed." },
  { id: "shipped", label: "Shipped", copy: "On the way to you." },
  { id: "delivered", label: "Delivered", copy: "Dropped. Wear it." },
];

function stepIndex(status: OrderStatus) {
  const s = normStatus(status);
  if (s === "cancelled") return -1;
  return STEPS.findIndex((x) => x.id === s);
}

function Track() {
  const { id: qid } = Route.useSearch();
  const orders = useOps((s) => s.orders);
  const [id, setId] = useState(qid ?? "");
  const [query, setQuery] = useState((qid ?? "").trim().toUpperCase());

  useEffect(() => {
    void useOps.persist.rehydrate();
  }, []);

  useEffect(() => {
    if (qid) {
      setId(qid);
      setQuery(qid.trim().toUpperCase());
    }
  }, [qid]);

  const order = useMemo(() => {
    if (!query) return undefined;
    return orders.find((o) => o.id.toUpperCase() === query);
  }, [orders, query]);

  function lookup(e: React.FormEvent) {
    e.preventDefault();
    setQuery(id.trim().toUpperCase());
  }

  return (
    <section className="mx-auto w-[min(720px,92%)] py-12">
      <p className="text-xs uppercase tracking-[0.2em] text-muted">Track</p>
      <h1 className="mt-2 font-display text-4xl font-bold">Where is my order?</h1>
      <p className="mt-2 text-muted">Enter the VOID order code from checkout. Same code staff has.</p>
      <form onSubmit={lookup} className="mt-6 flex flex-col gap-3 sm:flex-row">
        <input
          value={id}
          onChange={(e) => setId(e.target.value)}
          placeholder="VOID-100024"
          className="min-h-12 flex-1 rounded-md border border-border bg-surface px-3 uppercase"
        />
        <button type="submit" className="cut-btn min-h-12 bg-primary px-6 font-semibold">
          Track
        </button>
      </form>
      {query && !order && (
        <p className="mt-8 text-sm text-muted">No order with that ID. Check the code on your receipt.</p>
      )}
      {order && <TrackResult order={order} />}
    </section>
  );
}

function TrackResult({ order }: { order: OpsOrder }) {
  const cur = normStatus(order.status);
  const idx = stepIndex(order.status);

  return (
    <div className="mt-10">
      <p className="font-mono text-sm text-primary">{order.id}</p>
      <p className="mt-1 text-sm text-muted">
        Shipping to {order.city} {order.pincode}
      </p>
      {cur === "cancelled" ? (
        <p className="mt-6 rounded-xl border border-hot p-4 text-hot">This order was cancelled.</p>
      ) : (
        <ol className="mt-8 space-y-0">
          {STEPS.map((st, i) => {
            const done = idx >= i;
            const active = idx === i;
            return (
              <li key={st.id} className="flex gap-4">
                <div className="flex flex-col items-center">
                  <span
                    className={
                      "grid size-8 place-items-center rounded-full text-xs font-bold " +
                      (done ? "bg-primary text-[#070707]" : "border border-border text-muted")
                    }
                  >
                    {done ? "✓" : i + 1}
                  </span>
                  {i < STEPS.length - 1 && (
                    <span className={"h-10 w-px " + (idx > i ? "bg-primary" : "bg-border")} />
                  )}
                </div>
                <div className={"pb-8 " + (active ? "text-fg" : "text-muted")}>
                  <p className="font-semibold">{st.label}</p>
                  <p className="text-sm">{st.copy}</p>
                </div>
              </li>
            );
          })}
        </ol>
      )}
      <div className="rounded-xl border border-border bg-surface p-4 text-sm">
        {order.items.map((i) => (
          <p key={i.id}>
            {(i.code || productCode(i.id))} · {i.name} × {i.qty}
          </p>
        ))}
        <p className="mt-2 font-semibold text-primary">{inr(order.total)}</p>
      </div>
    </div>
  );
}
