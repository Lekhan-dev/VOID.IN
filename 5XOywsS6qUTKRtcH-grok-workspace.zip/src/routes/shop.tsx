import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo } from "react";
import { CATEGORY_TILES, CategoryCard } from "@/components/category-card";
import { ProductCard } from "@/components/product-card";
import { CATEGORIES, PRODUCTS, type ProductCategory } from "@/lib/products";
import { cn } from "@/lib/utils";

type ShopSearch = { cat?: ProductCategory | "all" };

export const Route = createFileRoute("/shop")({
  validateSearch: (s: Record<string, unknown>): ShopSearch => {
    const cat = s.cat;
    const ids: Array<ProductCategory | "all"> = [
      "all",
      "tees",
      "hoodies",
      "bottoms",
      "outerwear",
      "accessories",
    ];
    if (ids.includes(cat as ProductCategory | "all")) {
      return { cat: cat as ProductCategory | "all" };
    }
    return {};
  },
  component: Shop,
});

function Shop() {
  const { cat: rawCat } = Route.useSearch();
  const cat = rawCat ?? "all";
  const list = useMemo(
    () => (cat === "all" ? PRODUCTS : PRODUCTS.filter((p) => p.category === cat)),
    [cat],
  );

  return (
    <section className="mx-auto w-[min(1200px,92%)] py-6">
      <p className="text-xs uppercase tracking-[0.2em] text-muted">Shop</p>
      <h1 className="mt-2 font-display text-4xl font-bold">Categories</h1>
      <p className="mt-2 text-muted">Pick a lane. Then grab the drop.</p>
      <div className="cat-grid mt-4 grid gap-3 md:grid-cols-2">
        {CATEGORY_TILES.map((c) => (
          <CategoryCard key={c.cat} {...c} />
        ))}
      </div>
      <div className="mt-6 flex flex-wrap gap-2">
        {CATEGORIES.map((c) => (
          <Link
            key={c.id}
            to="/shop"
            search={c.id === "all" ? {} : { cat: c.id }}
            className={cn(
              "grid min-h-10 place-items-center rounded-full border px-4 text-sm font-medium",
              cat === c.id
                ? "border-primary bg-primary text-[#070707]"
                : "border-border text-muted hover:text-fg",
            )}
          >
            {c.label}
          </Link>
        ))}
      </div>
      <div className="mt-8 grid grid-cols-2 gap-3 md:grid-cols-5 md:gap-4">
        {list.map((p) => (
          <ProductCard key={p.id} product={p} />
        ))}
      </div>
    </section>
  );
}
