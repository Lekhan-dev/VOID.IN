import { createRootRoute, HeadContent, Outlet, Scripts } from "@tanstack/react-router";
import { AuthProvider } from "@/lib/auth/provider";
import { PreviewHostBridge } from "@/components/preview-host-bridge";
import { SiteShell } from "@/components/site-shell";
import appCss from "../styles.css?url";

const APP_NAME = "VOID";

const COOKIE_BOOT =
  '(function(){if(location.pathname.indexOf("/ops")===0)return;var K="void_cookie_choice";function go(){try{if(localStorage.getItem(K))return;}catch(e){}if(document.getElementById("void-cookie"))return;var w=document.createElement("div");w.id="void-cookie";w.className="void-cookie";w.setAttribute("role","dialog");w.setAttribute("aria-label","Cookie notice");w.innerHTML=\'<div class="void-cookie-box"><p>VOID uses necessary cookies and local storage for your cart and checkout. No ads. No sale of data. <a href="/privacy#cookies">Cookie policy</a></p><div class="void-cookie-actions"><button type="button" class="void-cookie-needed" data-cookie="needed">Necessary only</button><button type="button" class="void-cookie-accept" data-cookie="all">Accept</button></div></div>\';w.addEventListener("click",function(ev){var t=ev.target;if(!t||!t.closest)return;var b=t.closest("[data-cookie]");if(!b)return;try{localStorage.setItem(K,b.getAttribute("data-cookie")||"needed");}catch(e){}w.remove();});document.body.appendChild(w);}if(document.body)go();else document.addEventListener("DOMContentLoaded",go);})();';

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: APP_NAME },
      { name: "description", content: "VOID — streetwear by Lekhan and independent makers. Indian Gen-Z." },
      { name: "theme-color", content: "#070707" },
      { name: "referrer", content: "strict-origin-when-cross-origin" },
      { name: "robots", content: "index,follow" },
    ],
    links: [
      { rel: "icon", type: "image/svg+xml", href: "/favicon.svg" },
      { rel: "stylesheet", href: appCss },
      { rel: "manifest", href: "/__grok/manifest.webmanifest" },
      { rel: "apple-touch-icon", href: "/__grok/icon-180.png" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=Syne:wght@600;700;800&display=swap",
      },
    ],
    scripts: [
      { children: COOKIE_BOOT },
      { src: "/cat-tilt.js" },
      { src: "/ops-gate.js" },
      { src: "/cart-boot.js" },
    ],
  }),
  component: () => (
    <html lang="en" className="antialiased" suppressHydrationWarning>
      <head>
        <HeadContent />
      </head>
      <body className="bg-bg text-fg">
        <PreviewHostBridge />
        <AuthProvider>
          <SiteShell>
            <Outlet />
          </SiteShell>
        </AuthProvider>
        <Scripts />
      </body>
    </html>
  ),
});
