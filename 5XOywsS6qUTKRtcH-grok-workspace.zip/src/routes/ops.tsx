import { createFileRoute, Link } from "@tanstack/react-router";
import { Check, Bell, Package, Truck } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { STAFF_PIN, normStatus, stockOf, useOps, type OrderStatus } from "@/lib/ops";
import { productCode, PRODUCTS } from "@/lib/products";
import { playNewOrderSound, unlockAudio } from "@/lib/sfx";
import { cn, inr } from "@/lib/utils";

export const Route = createFileRoute("/ops")({ ssr: false, component: OpsApp });

const TABS = [
  { id: "orders", label: "Orders" },
  { id: "inventory", label: "Inventory" },
  { id: "delivery", label: "Delivery" },
  { id: "desk", label: "Desk" },
] as const;

const STATUSES: { id: OrderStatus; label: string }[] = [
  { id: "new", label: "New" },
  { id: "packing", label: "Packing" },
  { id: "shipped", label: "Shipped" },
  { id: "delivered", label: "Delivered" },
];

function OpsApp() {
  const [ok, setOk] = useState(() => {
    try {
      return sessionStorage.getItem("void_ops_ok") === "1";
    } catch {
      return false;
    }
  });
  const [pin, setPin] = useState("");
  const [tab, setTab] = useState<(typeof TABS)[number]["id"]>("orders");

  useEffect(() => {
    void useOps.persist.rehydrate();
    function unlockNow() {
      setOk(true);
    }
    window.addEventListener("void-ops-unlock", unlockNow);
    return () => window.removeEventListener("void-ops-unlock", unlockNow);
  }, []);

  function unlock(e: React.FormEvent) {
    e.preventDefault();
    if (pin.trim() !== STAFF_PIN) {
      toast.error("Wrong PIN");
      return;
    }
    try {
      sessionStorage.setItem("void_ops_ok", "1");
    } catch {
      /* ignore */
    }
    setOk(true);
    unlockAudio();
  }

  if (!ok) {
    return (
      <div className="grid min-h-dvh place-items-center px-4">
        <form
          id="ops-gate"
          onSubmit={unlock}
          className="w-full max-w-sm rounded-2xl border border-border bg-surface p-6"
        >
          <p className="text-xs uppercase tracking-[0.2em] text-muted">VOID Ops</p>
          <h1 className="mt-2 font-display text-3xl font-bold">Staff desk</h1>
          <p className="mt-2 text-sm text-muted">Orders, stock, and delivery.</p>
          <label className="mt-6 block text-xs uppercase tracking-widest text-muted">PIN</label>
          <input
            type="password"
            value={pin}
            onChange={(e) => setPin(e.target.value)}
            maxLength={24}
            autoComplete="current-password"
            className="mt-2 min-h-12 w-full rounded-md border border-border bg-bg px-3"
            placeholder="Staff PIN"
          />
          <p data-gate-err className="mt-3 min-h-5 text-center text-sm text-hot" />
          <button
            type="submit"
            className="mt-4 min-h-12 w-full rounded-full bg-primary font-semibold text-[#070707]"
          >
            Enter
          </button>
          <Link to="/" className="mt-4 block text-center text-xs text-muted hover:text-primary">
            Back to shop
          </Link>
        </form>
      </div>
    );
  }

  return (
    <div id="ops-desk" className="min-h-dvh bg-bg">
      <header className="sticky top-0 z-40 border-b border-border bg-bg">
        <div className="mx-auto flex h-14 w-[min(1200px,94%)] items-center justify-between gap-3">
          <p className="font-display text-lg font-extrabold">VOID Ops</p>
          <nav className="flex gap-1 text-sm">
            {TABS.map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => setTab(t.id)}
                className={cn(
                  "min-h-10 rounded-full px-3 font-medium",
                  tab === t.id ? "bg-primary text-[#070707]" : "text-muted hover:text-fg",
                )}
              >
                {t.label}
              </button>
            ))}
          </nav>
          <Inbox />
          <Link to="/" className="text-xs text-muted hover:text-primary">
            Customer site
          </Link>
        </div>
      </header>
      <div className="mx-auto w-[min(1200px,94%)] py-4">
        <Overview />
        {tab === "orders" && <OrdersPanel />}
        {tab === "inventory" && <InventoryPanel />}
        {tab === "delivery" && <DeliveryPanel />}
        {tab === "desk" && <DeskPanel />}
      </div>
    </div>
  );
}

function Inbox() {
  const orders = useOps((s) => s.orders);
  const seenIds = useOps((s) => s.seenIds) ?? [];
  const markSeen = useOps((s) => s.markSeen);
  const markAllSeen = useOps((s) => s.markAllSeen);
  const [open, setOpen] = useState(false);
  const primed = useRef(false);
  const prevLen = useRef(orders.length);
  const unread = orders.filter((o) => !seenIds.includes(o.id));

  useEffect(() => {
    if (!primed.current) {
      primed.current = true;
      prevLen.current = orders.length;
      return;
    }
    if (orders.length > prevLen.current) playNewOrderSound();
    prevLen.current = orders.length;
  }, [orders.length]);

  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="relative grid size-10 place-items-center rounded-full border border-border"
        aria-label="Order notifications"
      >
        <Bell className="size-4" />
        {unread.length > 0 && (
          <span className="absolute -right-1 -top-1 grid min-w-5 place-items-center rounded-full bg-hot px-1 text-[10px] font-bold text-white">
            {unread.length}
          </span>
        )}
      </button>
      {open && (
        <div className="absolute right-0 z-50 mt-2 w-80 rounded-xl border border-border bg-surface p-3 shadow-xl">
          <div className="flex items-center justify-between gap-2">
            <p className="text-sm font-semibold">New orders</p>
            {unread.length > 0 && (
              <button type="button" className="text-xs text-primary" onClick={() => markAllSeen()}>
                Mark all read
              </button>
            )}
          </div>
          <ul className="mt-2 max-h-72 space-y-2 overflow-auto">
            {unread.length === 0 && <li className="text-xs text-muted">Caught up. No missed orders.</li>}
            {unread.map((o) => (
              <li key={o.id} className="rounded-lg border border-border bg-bg p-2 text-xs">
                <p className="font-mono font-semibold text-primary">{o.id}</p>
                <p className="mt-1 font-medium">{o.name}</p>
                <p className="text-muted">
                  {o.items.map((i) => (i.code || productCode(i.id)) + " ×" + i.qty).join(", ")}
                </p>
                <button
                  type="button"
                  className="mt-2 text-primary"
                  onClick={() => markSeen(o.id)}
                >
                  Mark read
                </button>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

function Overview() {
  const orders = useOps((s) => s.orders);
  const live = orders.filter((o) => normStatus(o.status) !== "cancelled");
  const revenue = live.reduce((s, o) => s + o.total, 0);
  const profit = Math.round(
    live.reduce((s, o) => s + o.items.reduce((n, i) => n + i.price * i.qty, 0), 0) * 0.45,
  );
  const cards = [
    { label: "Total sales", value: inr(revenue), hint: "Paid orders" },
    { label: "Orders", value: String(live.length), hint: "All time" },
    { label: "Est. profit", value: inr(profit), hint: "45% on product" },
  ];
  return (
    <div className="mb-8 grid grid-cols-1 gap-3 sm:grid-cols-3">
      {cards.map((c) => (
        <div key={c.label} className="rounded-xl border border-border bg-surface p-4">
          <p className="text-[11px] uppercase tracking-widest text-muted">{c.label}</p>
          <p className="mt-1 font-display text-2xl font-bold tabular-nums">{c.value}</p>
          <p className="text-[11px] text-muted">{c.hint}</p>
        </div>
      ))}
    </div>
  );
}

function OrdersPanel() {
  const orders = useOps((s) => s.orders);
  const setStatus = useOps((s) => s.setStatus);
  const [q, setQ] = useState("");
  const list = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return orders;
    return orders.filter(
      (o) =>
        o.id.toLowerCase().includes(s) ||
        o.name.toLowerCase().includes(s) ||
        o.phone.includes(s) ||
        o.items.some((i) => i.name.toLowerCase().includes(s)),
    );
  }, [orders, q]);

  return (
    <div>
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="font-display text-3xl font-bold">Orders</h1>
          <p className="text-sm text-muted">{orders.length} total · tap a status to update</p>
        </div>
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search name, product, phone"
          className="min-h-11 w-full max-w-sm rounded-md border border-border bg-surface px-3 text-sm"
        />
      </div>
      <ul className="mt-6 space-y-3">
        {list.length === 0 && <p className="text-sm text-muted">No orders yet.</p>}
        {list.map((o) => {
          const cur = normStatus(o.status);
          const when = new Date(o.createdAt).toLocaleString("en-IN", {
            day: "2-digit",
            month: "short",
            hour: "2-digit",
            minute: "2-digit",
          });
          const units = o.items.reduce((n, i) => n + i.qty, 0);
          const label = STATUSES.find((s) => s.id === cur)?.label || cur;
          return (
            <li key={o.id} className="rounded-xl border border-border bg-surface p-4">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <p className="font-mono text-sm text-primary">{o.id}</p>
                  <p className="mt-1 font-display text-xl font-bold">{o.name}</p>
                  <p className="text-sm text-muted">{when}</p>
                </div>
                <div className="text-right">
                  <p className="rounded-full border border-primary px-3 py-1 text-xs font-semibold text-primary">
                    {label}
                  </p>
                  <p className="mt-2 font-display text-2xl font-bold tabular-nums">{inr(o.total)}</p>
                  <p className="text-xs text-muted">{units} piece{units === 1 ? "" : "s"}</p>
                </div>
              </div>
              <div className="mt-4 grid gap-4 md:grid-cols-2">
                <div className="rounded-lg border border-border bg-bg p-3 text-sm">
                  <p className="text-[11px] uppercase tracking-widest text-muted">Ship to</p>
                  <p className="mt-1 font-semibold">{o.name}</p>
                  <p>{o.address}</p>
                  <p>
                    {o.city}, {o.state} {o.pincode}
                  </p>
                  <a href={"tel:+91" + o.phone} className="mt-1 inline-block text-primary">
                    +91 {o.phone}
                  </a>
                </div>
                <div className="rounded-lg border border-border bg-bg p-3 text-sm">
                  <p className="text-[11px] uppercase tracking-widest text-muted">Items</p>
                  <ul className="mt-1 space-y-1">
                    {o.items.map((i) => (
                      <li key={i.id + i.name} className="flex justify-between gap-3">
                        <span>
                          <span className="font-mono text-primary">{i.code || productCode(i.id)}</span>{" "}
                          {i.name} × {i.qty}
                        </span>
                        <span className="tabular-nums">{inr(i.price * i.qty)}</span>
                      </li>
                    ))}
                  </ul>
                  <p className="mt-2 text-xs text-muted">{o.payment}</p>
                </div>
              </div>
              <div className="mt-3 flex flex-wrap gap-2">
                {STATUSES.map((st) => (
                  <button
                    key={st.id}
                    type="button"
                    onClick={() => {
                      setStatus(o.id, st.id);
                      toast.success(o.id + " → " + st.label);
                    }}
                    className={cn(
                      "min-h-9 rounded-full border px-3 text-xs font-semibold",
                      cur === st.id
                        ? "border-primary bg-primary text-[#070707]"
                        : "border-border text-muted hover:text-fg",
                    )}
                  >
                    {st.label}
                  </button>
                ))}
              </div>
            </li>
          );
        })}
      </ul>
    </div>
  );
}

function InventoryPanel() {
  const stock = useOps((s) => s.stock);
  const setStock = useOps((s) => s.setStock);
  const [q, setQ] = useState("");
  const list = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return PRODUCTS;
    return PRODUCTS.filter((p) => p.name.toLowerCase().includes(s) || p.category.includes(s));
  }, [q]);
  const low = PRODUCTS.filter((p) => stockOf(stock, p.id) <= 3).length;

  return (
    <div>
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="font-display text-3xl font-bold">Inventory</h1>
          <p className="text-sm text-muted">
            Edit stock here. Shop sold-out updates instantly. {low} low-stock SKUs.
          </p>
        </div>
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search product"
          className="min-h-11 w-full max-w-sm rounded-md border border-border bg-surface px-3 text-sm"
        />
      </div>
      <div className="mt-6 overflow-x-auto rounded-xl border border-border">
        <table className="w-full min-w-[640px] text-left text-sm">
          <thead className="bg-elevated text-xs uppercase tracking-wider text-muted">
            <tr>
              <th className="px-3 py-3">Code</th>
              <th className="px-3 py-3">Product</th>
              <th className="px-3 py-3">Lane</th>
              <th className="px-3 py-3">Price</th>
              <th className="px-3 py-3">Stock</th>
            </tr>
          </thead>
          <tbody>
            {list.map((p) => {
              const n = stockOf(stock, p.id);
              return (
                <tr key={p.id} className="border-t border-border">
                  <td className="px-3 py-3 font-mono text-xs text-primary">{productCode(p.id)}</td>
                  <td className="px-3 py-3 font-medium">{p.name}</td>
                  <td className="px-3 py-3 text-muted">{p.catLabel}</td>
                  <td className="px-3 py-3 tabular-nums">{inr(p.price)}</td>
                  <td className="px-3 py-3">
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        className="grid size-9 place-items-center rounded-md border border-border"
                        onClick={() => setStock(p.id, n - 1)}
                      >
                        −
                      </button>
                      <input
                        type="number"
                        min={0}
                        max={999}
                        value={n}
                        onChange={(e) => setStock(p.id, Number(e.target.value) || 0)}
                        className={cn(
                          "h-9 w-16 rounded-md border bg-bg text-center tabular-nums",
                          n === 0
                            ? "border-hot text-hot"
                            : n <= 3
                              ? "border-primary text-primary"
                              : "border-border",
                        )}
                      />
                      <button
                        type="button"
                        className="grid size-9 place-items-center rounded-md border border-border"
                        onClick={() => setStock(p.id, n + 1)}
                      >
                        +
                      </button>
                      {n === 0 && <span className="text-xs font-semibold text-hot">Sold out</span>}
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function DeliveryPanel() {
  const orders = useOps((s) => s.orders);
  const setStatus = useOps((s) => s.setStatus);
  const lanes: { id: OrderStatus; title: string; icon: typeof Package; next?: OrderStatus }[] = [
    { id: "packing", title: "Packing", icon: Package, next: "shipped" },
    { id: "shipped", title: "Shipped", icon: Truck, next: "delivered" },
    { id: "delivered", title: "Delivered", icon: Check },
  ];

  return (
    <div>
      <h1 className="font-display text-3xl font-bold">Delivery</h1>
      <p className="text-sm text-muted">Packing → Shipped → Delivered. Customers see the same steps.</p>
      <div className="mt-6 grid gap-4 md:grid-cols-3">
        {lanes.map((lane) => {
          const Icon = lane.icon;
          const items = orders.filter((o) => normStatus(o.status) === lane.id);
          return (
            <section key={lane.id} className="rounded-xl border border-border bg-surface p-4">
              <p className="flex items-center gap-2 text-sm font-semibold">
                <Icon className="size-4 text-primary" />
                {lane.title}
                <span className="text-muted">({items.length})</span>
              </p>
              <ul className="mt-3 space-y-2">
                {items.length === 0 && <li className="text-xs text-muted">Empty lane</li>}
                {items.map((o) => (
                  <li key={o.id} className="rounded-lg border border-border bg-bg p-3">
                    <p className="font-mono text-xs text-primary">{o.id}</p>
                    <p className="text-sm font-semibold">{o.name}</p>
                    <p className="text-xs text-muted">
                      {o.address}, {o.city} {o.pincode}
                    </p>
                    <p className="mt-1 text-xs text-muted">
                      {o.items.map((i) => (i.code || productCode(i.id)) + " " + i.name + " ×" + i.qty).join(", ")}
                    </p>
                    {lane.next && (
                      <button
                        type="button"
                        className="mt-2 min-h-9 w-full rounded-full bg-primary text-xs font-semibold text-[#070707]"
                        onClick={() => setStatus(o.id, lane.next!)}
                      >
                        {lane.next === "shipped" ? "Mark shipped" : "Mark delivered"}
                      </button>
                    )}
                  </li>
                ))}
              </ul>
            </section>
          );
        })}
      </div>
    </div>
  );
}

function DeskPanel() {
  const notes = useOps((s) => s.notes) ?? [];
  const markNoteRead = useOps((s) => s.markNoteRead);
  const unread = notes.filter((n) => !n.read).length;
  return (
    <div>
      <h1 className="font-display text-3xl font-bold">Desk</h1>
      <p className="text-sm text-muted">Notes from Write to us. {unread} unread.</p>
      <ul className="mt-4 space-y-3">
        {notes.length === 0 && <li className="text-sm text-muted">No notes yet.</li>}
        {notes.map((n) => (
          <li key={n.id} className="rounded-xl border border-border bg-surface p-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="font-mono text-xs text-primary">{n.id}</p>
                <p className="mt-1 font-semibold">{n.name}</p>
                {n.email && <p className="text-xs text-muted">{n.email}</p>}
              </div>
              {!n.read && (
                <button
                  type="button"
                  className="min-h-8 rounded-full bg-primary px-3 text-xs font-semibold text-[#070707]"
                  onClick={() => markNoteRead(n.id)}
                >
                  Mark read
                </button>
              )}
            </div>
            <p className="mt-3 whitespace-pre-wrap text-sm">{n.message}</p>
          </li>
        ))}
      </ul>
    </div>
  );
}
