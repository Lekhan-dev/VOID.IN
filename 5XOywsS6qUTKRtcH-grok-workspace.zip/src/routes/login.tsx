import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { GROK_PROVIDERS, authClient, authEnabled, signIn } from "@/lib/auth/client";

type Mode = "signin" | "signup";

export const Route = createFileRoute("/login")({
  validateSearch: (s: Record<string, unknown>): { mode?: Mode; next?: string } => ({
    mode: s.mode === "signup" ? "signup" : s.mode === "signin" ? "signin" : undefined,
    next: typeof s.next === "string" && s.next.startsWith("/") ? s.next : undefined,
  }),
  component: Login,
});

function Login() {
  const { mode: q, next } = Route.useSearch();
  const navigate = useNavigate();
  const [mode, setMode] = useState<Mode>(q ?? "signin");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  async function onEmail(e: React.FormEvent) {
    e.preventDefault();
    setErr("");
    setBusy(true);
    try {
      if (mode === "signup") {
        const res = await authClient.signUp.email({
          name: name.trim() || email.split("@")[0],
          email: email.trim(),
          password,
          callbackURL: next || "/",
        });
        if (res.error) throw new Error(res.error.message || "Sign up failed");
      } else {
        const res = await authClient.signIn.email({
          email: email.trim(),
          password,
          callbackURL: next || "/",
        });
        if (res.error) throw new Error(res.error.message || "Sign in failed");
      }
      const label = name.trim() || email.split("@")[0] || "Account";
      try {
        sessionStorage.setItem("void_me", JSON.stringify({ name: label, email: email.trim() }));
      } catch {
        /* ignore */
      }
      await authClient.getSession().catch(() => undefined);
      void navigate({ to: next && next.startsWith("/") ? next : "/" });
    } catch (ex) {
      setErr(ex instanceof Error ? ex.message : "Try again");
      setBusy(false);
    }
  }

  return (
    <section className="mx-auto grid min-h-[70dvh] w-[min(420px,92%)] place-items-center py-12">
      <div className="w-full rounded-2xl border border-border bg-surface p-6">
        <p className="text-xs uppercase tracking-[0.2em] text-muted">VOID</p>
        <h1 className="mt-2 font-display text-3xl font-bold">
          {mode === "signup" ? "Sign up" : "Sign in"}
        </h1>
        <div className="mt-4 grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={() => setMode("signin")}
            className={
              "min-h-10 rounded-full text-sm font-semibold " +
              (mode === "signin" ? "bg-primary text-[#070707]" : "border border-border text-muted")
            }
          >
            Sign in
          </button>
          <button
            type="button"
            onClick={() => setMode("signup")}
            className={
              "min-h-10 rounded-full text-sm font-semibold " +
              (mode === "signup" ? "bg-primary text-[#070707]" : "border border-border text-muted")
            }
          >
            Sign up
          </button>
        </div>
        {authEnabled ? (
          <>
            <div className="mt-5 space-y-2">
              {GROK_PROVIDERS.map((p) => (
                <button
                  key={p.providerId}
                  type="button"
                  onClick={() => signIn(p.providerId, { callbackURL: next || "/" })}
                  className="min-h-12 w-full rounded-md border border-border font-semibold hover:border-primary"
                >
                  Continue with {p.label}
                </button>
              ))}
            </div>
            <p className="my-4 text-center text-xs uppercase tracking-widest text-muted">or email</p>
            <form onSubmit={onEmail} className="space-y-3">
              {mode === "signup" && (
                <input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Name"
                  className="min-h-12 w-full rounded-md border border-border bg-bg px-3"
                />
              )}
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Email"
                className="min-h-12 w-full rounded-md border border-border bg-bg px-3"
              />
              <input
                type="password"
                required
                minLength={8}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Password"
                className="min-h-12 w-full rounded-md border border-border bg-bg px-3"
              />
              {err && <p className="text-sm text-hot">{err}</p>}
              <button
                type="submit"
                disabled={busy}
                className="cut-btn min-h-12 w-full bg-primary font-semibold disabled:opacity-60"
              >
                {busy ? "Working…" : mode === "signup" ? "Create account" : "Sign in"}
              </button>
            </form>
          </>
        ) : (
          <p className="mt-4 text-sm text-muted">Sign-in is disabled.</p>
        )}
      </div>
    </section>
  );
}
