import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { useOps } from "@/lib/ops";
import { cleanText, isEmail, tooSoon } from "@/lib/security";

export const Route = createFileRoute("/write")({ component: WriteDesk });

function WriteDesk() {
  const addNote = useOps((s) => s.addNote);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [sent, setSent] = useState(false);

  function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    const n = cleanText(name, 80);
    const em = cleanText(email, 120);
    const msg = cleanText(message, 800);
    if (!n || !msg) {
      toast.error("Name and message needed");
      return;
    }
    if (em && !isEmail(em)) {
      toast.error("That email looks off");
      return;
    }
    if (tooSoon("void_desk", 4000)) {
      toast.error("Wait a second");
      return;
    }
    addNote({ name: n, email: em, message: msg });
    setSent(true);
    setMessage("");
    toast.success("Dropped on the desk");
  }

  return (
    <section className="desk-wrap">
      <div className="desk-top">
        <div className="desk-lamp" aria-hidden="true" />
        <form className="desk-paper" onSubmit={onSubmit}>
          <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-[#6b5d3f]">
            VOID desk
          </p>
          <h1 className="mt-1 font-display text-3xl font-bold text-[#1a160f]">Write to us</h1>
          <p className="mt-1 text-sm text-[#6b5d3f]">Leave a note. Staff sees it on the ops desk.</p>
          {sent ? (
            <p className="mt-8 font-display text-xl font-bold text-[#1a160f]">Got it. We’ll read it.</p>
          ) : (
            <>
              <input
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Your name"
                maxLength={80}
                className="desk-line mt-6"
              />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Email (optional)"
                maxLength={120}
                className="desk-line mt-3"
              />
              <textarea
                required
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Write it like a note on the desk…"
                maxLength={800}
                rows={6}
                className="desk-area mt-3"
              />
              <button
                type="submit"
                className="mt-5 min-h-11 bg-[#1a160f] px-6 text-sm font-semibold text-[#efe6cc]"
              >
                Leave on desk
              </button>
            </>
          )}
        </form>
      </div>
    </section>
  );
}
