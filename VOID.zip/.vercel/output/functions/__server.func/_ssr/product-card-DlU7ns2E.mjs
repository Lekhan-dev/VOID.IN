import { x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Plus } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as useCart, r as inr } from "./router-CLN9uA0j.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/product-card-DlU7ns2E.js
var import_jsx_runtime = require_jsx_runtime();
function ProductCard({ product }) {
	const add = useCart((s) => s.add);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "group overflow-hidden rounded-lg border border-border bg-surface",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative aspect-[3/4] overflow-hidden bg-elevated",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: product.img,
					alt: product.name,
					width: 800,
					height: 1e3,
					loading: "lazy",
					decoding: "async",
					className: "h-full w-full object-cover transition duration-500 group-hover:scale-105"
				}),
				product.badge && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "absolute left-3 top-3 rounded-md px-2 py-1 text-[10px] font-bold uppercase tracking-wide " + (product.badge === "hot" ? "bg-hot text-fg" : product.badge === "limited" ? "border border-primary bg-elevated text-primary" : "bg-primary text-fg"),
					children: product.badge
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "absolute inset-x-3 bottom-3 flex min-h-11 items-center justify-center gap-1 rounded-md bg-fg text-sm font-semibold text-bg opacity-100 transition hover:bg-primary hover:text-fg md:opacity-0 md:group-hover:opacity-100",
					onClick: () => {
						add({
							id: product.id,
							name: product.name,
							price: product.price,
							img: product.img
						});
						toast.success("Added " + product.name);
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "Quick Add"]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "p-3 md:p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[10px] uppercase tracking-[0.14em] text-muted",
					children: product.catLabel
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mt-1 font-medium leading-snug",
					children: product.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 line-clamp-2 text-xs text-muted",
					children: product.desc
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 font-semibold tabular-nums text-primary",
					children: inr(product.price)
				})
			]
		})]
	});
}
//#endregion
export { ProductCard as t };
