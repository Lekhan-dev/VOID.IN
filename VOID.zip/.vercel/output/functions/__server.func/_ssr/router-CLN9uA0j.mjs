import { i as __toESM } from "../_runtime.mjs";
import { B as require_react, _ as createFileRoute, b as useRouter, d as HeadContent, f as useRouterState, g as lazyRouteComponent, h as Outlet, m as createRouter, u as Scripts, v as createRootRoute, x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as ShoppingBag, n as TriangleAlert, s as Menu, t as X } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-CLN9uA0j.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: error.message || "An unexpected error occurred. Try reloading the page."
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	if (typeof window === "undefined") return () => {};
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	const parentOrigin = resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		if (envelope.data.type === "hello") {
			if (!HelloSchema.safeParse(event.data).success) return;
			announce();
			return;
		}
		if (envelope.data.type === "navigate") {
			const parsed = NavigateSchema.safeParse(event.data);
			if (!parsed.success) return;
			navigate(parsed.data.path);
			queueMicrotask(reportLocation);
			return;
		}
		if (envelope.data.type === "history") {
			const parsed = HistorySchema.safeParse(event.data);
			if (!parsed.success) return;
			if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
			window.history.go(parsed.data.delta);
		}
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var u = (id) => `https://images.unsplash.com/${id}?w=800&q=80&auto=format&fit=crop`;
var PRODUCTS = [
	{
		id: "chaos-tee",
		name: "Chaos Oversized Tee",
		price: 1299,
		category: "tees",
		catLabel: "Graphic Tee",
		badge: "new",
		desc: "220 GSM cotton. Boxy oversized fit. Loud front print for daily street wear.",
		img: u("photo-1583743814966-8936f5b7be1a")
	},
	{
		id: "night-hoodie",
		name: "Night Mode Hoodie",
		price: 2499,
		category: "hoodies",
		catLabel: "Heavyweight",
		badge: "hot",
		desc: "400 GSM fleece. Drop shoulders. Built for late-night rides and cold AC.",
		img: u("photo-1556821840-3a63f95609a7")
	},
	{
		id: "utility-cargo",
		name: "Utility Cargo Pants",
		price: 1899,
		category: "bottoms",
		catLabel: "Bottoms",
		badge: null,
		desc: "Multi-pocket cargo. Relaxed fit. Durable fabric for all-day city moves.",
		img: u("photo-1624378439575-d8705ad7ae80")
	},
	{
		id: "shadow-bomber",
		name: "Shadow Bomber",
		price: 3499,
		category: "outerwear",
		catLabel: "Outerwear",
		badge: "limited",
		desc: "Lightweight bomber. Ribbed cuffs. Clean silhouette for night outs.",
		img: u("photo-1591047139829-d91aecb6caea")
	},
	{
		id: "core-cap",
		name: "Core Cap",
		price: 799,
		category: "accessories",
		catLabel: "Accessories",
		badge: null,
		desc: "Structured cap. Adjustable strap. Minimal VOID embroidery.",
		img: u("photo-1588850561407-ed78c282e89b")
	},
	{
		id: "relaxed-shorts",
		name: "Relaxed Shorts",
		price: 999,
		category: "bottoms",
		catLabel: "Bottoms",
		badge: "new",
		desc: "Above-knee relaxed shorts. Soft cotton. Easy summer essential.",
		img: u("photo-1591195853828-11db59a44f6b")
	},
	{
		id: "void-tee",
		name: "Void Graphic Tee",
		price: 1399,
		category: "tees",
		catLabel: "Graphic Tee",
		badge: null,
		desc: "Heavy cotton tee. Bold back graphic. Slightly cropped oversized cut.",
		img: u("photo-1576566588028-4147f3842f27")
	},
	{
		id: "storm-hoodie",
		name: "Storm Hoodie",
		price: 2699,
		category: "hoodies",
		catLabel: "Heavyweight",
		badge: null,
		desc: "Washed finish hoodie. Kangaroo pocket. Soft inside, tough outside.",
		img: u("photo-1578768076945-8d57054b5ba5")
	},
	{
		id: "pulse-tee",
		name: "Pulse Oversized Tee",
		price: 1199,
		category: "tees",
		catLabel: "Graphic Tee",
		badge: "new",
		desc: "Breathable mid-weight tee. Wide sleeves. Everyday Gen-Z staple.",
		img: u("photo-1521572163474-6864f9cf17ab")
	},
	{
		id: "drift-pants",
		name: "Drift Wide Pants",
		price: 2199,
		category: "bottoms",
		catLabel: "Bottoms",
		badge: "hot",
		desc: "Wide-leg silhouette. Elastic waist. Moves with you, looks expensive.",
		img: u("photo-1542272604-787c3835535d")
	},
	{
		id: "neon-tee",
		name: "Neon Drop Tee",
		price: 1249,
		category: "tees",
		catLabel: "Graphic Tee",
		badge: "new",
		desc: "High-contrast print tee. Soft hand-feel. Limited colourway drop.",
		img: u("photo-1618354691373-d851c5c3a990")
	},
	{
		id: "blackout-hoodie",
		name: "Blackout Hoodie",
		price: 2599,
		category: "hoodies",
		catLabel: "Heavyweight",
		badge: null,
		desc: "All-black heavyweight. Double-layered hood. Zero logos energy.",
		img: u("photo-1509942774185-799d268f5b9f")
	},
	{
		id: "baggy-denim",
		name: "Baggy Denim",
		price: 2499,
		category: "bottoms",
		catLabel: "Bottoms",
		badge: "hot",
		desc: "90s baggy denim. Mid wash. Room for sneakers and attitude.",
		img: u("photo-1541099649105-f69ad21f3246")
	},
	{
		id: "varsity-jacket",
		name: "Varsity Jacket",
		price: 3999,
		category: "outerwear",
		catLabel: "Outerwear",
		badge: "limited",
		desc: "Classic varsity cut. Contrast sleeves. Campus to street ready.",
		img: u("photo-1551028719-00167b16eac5")
	},
	{
		id: "bucket-hat",
		name: "Bucket Hat",
		price: 899,
		category: "accessories",
		catLabel: "Accessories",
		badge: null,
		desc: "Cotton bucket hat. Soft brim. Festival and heat essential.",
		img: u("photo-1521369909029-2afed882baee")
	},
	{
		id: "cargo-shorts",
		name: "Cargo Shorts",
		price: 1299,
		category: "bottoms",
		catLabel: "Bottoms",
		badge: null,
		desc: "Utility shorts with side pockets. Light fabric for humid days.",
		img: u("photo-1591195853828-11db59a44f6b")
	},
	{
		id: "glitch-tee",
		name: "Glitch Print Tee",
		price: 1349,
		category: "tees",
		catLabel: "Graphic Tee",
		badge: "new",
		desc: "Digital glitch artwork. Soft oversized body. Conversation starter.",
		img: u("photo-1562157873-818bc0726f68")
	},
	{
		id: "zip-hoodie",
		name: "Zip Tech Hoodie",
		price: 2799,
		category: "hoodies",
		catLabel: "Heavyweight",
		badge: "hot",
		desc: "Full-zip tech hoodie. Clean hardware. Layer over tees easily.",
		img: u("photo-1620799140408-edc6dcb6d633")
	},
	{
		id: "wide-cargo",
		name: "Wide Cargo Pants",
		price: 2099,
		category: "bottoms",
		catLabel: "Bottoms",
		badge: null,
		desc: "Extra-wide cargos. Drawcord hem. Max comfort, max pockets.",
		img: u("photo-1473966968600-fa801b869a1a")
	},
	{
		id: "puffer-vest",
		name: "Puffer Vest",
		price: 2999,
		category: "outerwear",
		catLabel: "Outerwear",
		badge: "limited",
		desc: "Lightweight puffer vest. Packable warmth without bulk.",
		img: u("photo-1544923246-77307dd28ed4")
	},
	{
		id: "beanie",
		name: "Core Beanie",
		price: 699,
		category: "accessories",
		catLabel: "Accessories",
		badge: null,
		desc: "Rib-knit beanie. Soft stretch. Winter layer that stays simple.",
		img: u("photo-1576871337632-b9aef4c17ab9")
	},
	{
		id: "boxy-tee",
		name: "Boxy Fit Tee",
		price: 1199,
		category: "tees",
		catLabel: "Graphic Tee",
		badge: null,
		desc: "True boxy cut. Thick collar. Pairs with cargos and denim.",
		img: u("photo-1586790170083-2f9ceadc732d")
	},
	{
		id: "oversized-hoodie",
		name: "Oversized Cloud Hoodie",
		price: 2699,
		category: "hoodies",
		catLabel: "Heavyweight",
		badge: "new",
		desc: "Cloud-soft fleece. Extra long sleeves. Coziest piece in the drop.",
		img: u("photo-1515886657613-9f3515b0c78f")
	},
	{
		id: "track-pants",
		name: "Track Pants",
		price: 1799,
		category: "bottoms",
		catLabel: "Bottoms",
		badge: null,
		desc: "Tapered track pants. Side stripe detail. Gym to street.",
		img: u("photo-1552902865-b72c031ac5ea")
	},
	{
		id: "denim-jacket",
		name: "Raw Denim Jacket",
		price: 3599,
		category: "outerwear",
		catLabel: "Outerwear",
		badge: "hot",
		desc: "Classic denim jacket. Raw indigo. Ages with every wear.",
		img: u("photo-1576995853123-5a10305d93c0")
	},
	{
		id: "socks-pack",
		name: "Crew Socks Pack",
		price: 499,
		category: "accessories",
		catLabel: "Accessories",
		badge: null,
		desc: "3-pack crew socks. Cushioned sole. Full height.",
		img: u("photo-1586350977771-b3b0abd50f80")
	},
	{
		id: "acid-tee",
		name: "Acid Wash Tee",
		price: 1399,
		category: "tees",
		catLabel: "Graphic Tee",
		badge: "new",
		desc: "Acid-wash texture. Vintage fade. Each piece looks slightly unique.",
		img: u("photo-1529374255404-311a2a4f1fd9")
	},
	{
		id: "cropped-hoodie",
		name: "Cropped Hoodie",
		price: 2299,
		category: "hoodies",
		catLabel: "Heavyweight",
		badge: null,
		desc: "Cropped length hoodie. Clean hem. Layer over high-waist fits.",
		img: u("photo-1618354691438-25bc04584c23")
	},
	{
		id: "parachute-pants",
		name: "Parachute Pants",
		price: 2399,
		category: "bottoms",
		catLabel: "Bottoms",
		badge: "hot",
		desc: "Parachute nylon feel. Cinched ankles. Main-character pants.",
		img: u("photo-1506629082955-511b1aa784c1")
	},
	{
		id: "coach-jacket",
		name: "Coach Jacket",
		price: 3199,
		category: "outerwear",
		catLabel: "Outerwear",
		badge: null,
		desc: "Water-resistant coach jacket. Snap buttons. Light layer king.",
		img: u("photo-1487222477894-8943e31ef7b2")
	},
	{
		id: "crossbody",
		name: "Crossbody Bag",
		price: 1499,
		category: "accessories",
		catLabel: "Accessories",
		badge: "new",
		desc: "Compact crossbody. Adjustable strap. Phone, wallet, keys done.",
		img: u("photo-1548036328-c9fa89d128fa")
	},
	{
		id: "retro-tee",
		name: "Retro Wave Tee",
		price: 1299,
		category: "tees",
		catLabel: "Graphic Tee",
		badge: null,
		desc: "Retro wave graphic. Soft washed cotton. Y2K without trying too hard.",
		img: u("photo-1503342217505-b0a15ec3261c")
	},
	{
		id: "fleece-hoodie",
		name: "Fleece Hoodie",
		price: 2499,
		category: "hoodies",
		catLabel: "Heavyweight",
		badge: null,
		desc: "Plush fleece inside. Ribbed hem. Winter daily driver.",
		img: u("photo-1556821840-3a63f95609a7")
	},
	{
		id: "joggers",
		name: "Tapered Joggers",
		price: 1699,
		category: "bottoms",
		catLabel: "Bottoms",
		badge: null,
		desc: "Tapered joggers. Soft stretch. Travel and chill uniform.",
		img: u("photo-1552902865-b72c031ac5ea")
	},
	{
		id: "windbreaker",
		name: "Windbreaker",
		price: 2799,
		category: "outerwear",
		catLabel: "Outerwear",
		badge: "limited",
		desc: "Packable windbreaker. Neon zip detail. Monsoon-ready shell.",
		img: u("photo-1544923246-77307dd28ed4")
	},
	{
		id: "chain-necklace",
		name: "Chain Necklace",
		price: 799,
		category: "accessories",
		catLabel: "Accessories",
		badge: null,
		desc: "Stainless chain. Water-resistant. Stack or wear solo.",
		img: u("photo-1611652022419-a9419f74343d")
	},
	{
		id: "heavy-tee",
		name: "Heavyweight Blank Tee",
		price: 999,
		category: "tees",
		catLabel: "Graphic Tee",
		badge: null,
		desc: "Blank heavyweight tee. Premium blank for pure fit flex.",
		img: u("photo-1521572163474-6864f9cf17ab")
	},
	{
		id: "sherpa-hoodie",
		name: "Sherpa Lined Hoodie",
		price: 3299,
		category: "hoodies",
		catLabel: "Heavyweight",
		badge: "hot",
		desc: "Sherpa-lined warmth. Serious winter piece. Looks premium.",
		img: u("photo-1578768076945-8d57054b5ba5")
	},
	{
		id: "carpenter-pants",
		name: "Carpenter Pants",
		price: 2299,
		category: "bottoms",
		catLabel: "Bottoms",
		badge: "new",
		desc: "Carpenter utility pants. Loop details. Workwear meets street.",
		img: u("photo-1624378439575-d8705ad7ae80")
	},
	{
		id: "leather-jacket",
		name: "Faux Leather Jacket",
		price: 4499,
		category: "outerwear",
		catLabel: "Outerwear",
		badge: "limited",
		desc: "Faux leather biker cut. Soft lining. Night-out uniform.",
		img: u("photo-1521223890158-f9f7c3d5d504")
	},
	{
		id: "sunglasses",
		name: "Void Sunglasses",
		price: 1299,
		category: "accessories",
		catLabel: "Accessories",
		badge: null,
		desc: "UV-protected shades. Matte frame. Instant main-character energy.",
		img: u("photo-1511499767150-a48a237ac008")
	},
	{
		id: "stripe-tee",
		name: "Stripe Oversized Tee",
		price: 1199,
		category: "tees",
		catLabel: "Graphic Tee",
		badge: null,
		desc: "Horizontal stripe tee. Soft jersey. Easy weekend fit.",
		img: u("photo-1562157873-818bc0726f68")
	},
	{
		id: "halfzip-hoodie",
		name: "Half-Zip Hoodie",
		price: 2599,
		category: "hoodies",
		catLabel: "Heavyweight",
		badge: "new",
		desc: "Half-zip pullover. Clean collar. Smart-casual street hybrid.",
		img: u("photo-1620799140408-edc6dcb6d633")
	},
	{
		id: "pleated-pants",
		name: "Pleated Wide Pants",
		price: 2499,
		category: "bottoms",
		catLabel: "Bottoms",
		badge: null,
		desc: "Pleated wide pants. Flowy drape. Elevated street look.",
		img: u("photo-1473966968600-fa801b869a1a")
	},
	{
		id: "utility-vest",
		name: "Utility Vest",
		price: 2699,
		category: "outerwear",
		catLabel: "Outerwear",
		badge: "hot",
		desc: "Multi-pocket utility vest. Layer over hoodies and tees.",
		img: u("photo-1434389677669-e08b4cac3105")
	},
	{
		id: "ring-set",
		name: "Ring Set",
		price: 599,
		category: "accessories",
		catLabel: "Accessories",
		badge: null,
		desc: "3-piece ring set. Mixed finishes. Stack for detail.",
		img: u("photo-1605100804763-247f67b3557e")
	},
	{
		id: "desi-tee",
		name: "Desi Drip Tee",
		price: 1299,
		category: "tees",
		catLabel: "Graphic Tee",
		badge: "new",
		desc: "India-inspired graphic tee. Soft cotton. Made for desi Gen-Z energy.",
		img: u("photo-1576566588028-4147f3842f27")
	},
	{
		id: "mumbai-hoodie",
		name: "Mumbai Nights Hoodie",
		price: 2599,
		category: "hoodies",
		catLabel: "Heavyweight",
		badge: "hot",
		desc: "City-night graphic hoodie. Heavy fleece. Built for late Mumbai runs.",
		img: u("photo-1515886657613-9f3515b0c78f")
	},
	{
		id: "delhi-cargo",
		name: "Delhi Cargo Pants",
		price: 1999,
		category: "bottoms",
		catLabel: "Bottoms",
		badge: null,
		desc: "City cargo pants. Tough fabric. Pocket space for the whole day.",
		img: u("photo-1542272604-787c3835535d")
	},
	{
		id: "genz-cap",
		name: "GenZ Snapback",
		price: 849,
		category: "accessories",
		catLabel: "Accessories",
		badge: "new",
		desc: "Flat-brim snapback. Bold VOID mark. Instant head-to-toe finish.",
		img: u("photo-1521369909029-2afed882baee")
	}
];
var CATEGORIES = [
	{
		id: "all",
		label: "All"
	},
	{
		id: "tees",
		label: "Tees"
	},
	{
		id: "hoodies",
		label: "Hoodies"
	},
	{
		id: "bottoms",
		label: "Bottoms"
	},
	{
		id: "outerwear",
		label: "Outerwear"
	},
	{
		id: "accessories",
		label: "Accessories"
	}
];
var useCart = create()(persist((set, get) => ({
	items: [],
	add: (item) => {
		if (get().items.find((i) => i.id === item.id)) set({ items: get().items.map((i) => i.id === item.id ? {
			...i,
			qty: i.qty + 1
		} : i) });
		else set({ items: [...get().items, {
			...item,
			qty: 1
		}] });
	},
	setQty: (id, qty) => {
		if (qty < 1) {
			set({ items: get().items.filter((i) => i.id !== id) });
			return;
		}
		set({ items: get().items.map((i) => i.id === id ? {
			...i,
			qty
		} : i) });
	},
	remove: (id) => set({ items: get().items.filter((i) => i.id !== id) }),
	clear: () => set({ items: [] })
}), {
	name: "void_cart",
	skipHydration: true
}));
function cartCount(items) {
	return items.reduce((s, i) => s + i.qty, 0);
}
function cartSubtotal(items) {
	return items.reduce((s, i) => s + i.price * i.qty, 0);
}
function cartTotals(items) {
	const subtotal = cartSubtotal(items);
	const shipping = subtotal > 0 ? 99 : 0;
	return {
		subtotal,
		shipping,
		total: subtotal + shipping
	};
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function inr(n) {
	return "₹" + n.toLocaleString("en-IN");
}
var NAV = [
	{
		to: "/",
		label: "Home"
	},
	{
		to: "/shop",
		label: "Shop"
	},
	{
		to: "/checkout",
		label: "Cart"
	}
];
function SiteShell({ children }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const count = useCart((s) => cartCount(s.items));
	(0, import_react.useEffect)(() => {
		useCart.persist.rehydrate();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				theme: "dark",
				position: "bottom-center"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-40 border-b border-border bg-bg/90 backdrop-blur-md",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex h-16 w-[min(1200px,92%)] items-center justify-between",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							className: "font-display text-xl font-extrabold tracking-tight",
							children: "VOID"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
							className: "hidden items-center gap-8 text-sm font-medium md:flex",
							children: NAV.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: n.to,
								className: cn("transition-colors hover:text-primary", pathname === n.to ? "text-fg" : "text-muted"),
								children: n.label
							}, n.to))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/checkout",
								className: "relative grid size-11 place-items-center rounded-full border border-border",
								"aria-label": "Cart",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingBag, { className: "size-5" }), count > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "absolute -right-1 -top-1 grid min-w-5 place-items-center rounded-full bg-primary px-1 text-[10px] font-bold text-fg tabular-nums",
									children: count
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "grid size-11 place-items-center rounded-full border border-border md:hidden",
								"aria-label": open ? "Close menu" : "Open menu",
								onClick: () => setOpen((v) => !v),
								children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
							})]
						})
					]
				}), open && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border-t border-border px-[4%] py-4 md:hidden",
					children: [NAV.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: n.to,
						onClick: () => setOpen(false),
						className: "block py-3 text-lg font-medium",
						children: n.label
					}, n.to)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "pt-2 text-xs text-muted",
						children: "Founded by Lekhan"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", { children }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "mt-16 border-t border-border",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex w-[min(1200px,92%)] flex-col gap-8 py-12 md:flex-row md:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl font-extrabold",
						children: "VOID"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm text-muted",
						children: [
							"Selfmade streetwear.",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							"Founded by Lekhan."
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-12 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/shop",
								className: "hover:text-primary",
								children: "Shop"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/",
								hash: "story",
								className: "hover:text-primary",
								children: "Story"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/terms",
								className: "hover:text-primary",
								children: "Terms"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/privacy",
								className: "hover:text-primary",
								children: "Privacy"
							})]
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "border-t border-border py-4 text-center text-xs text-muted",
					children: "© 2026 VOID. All rights reserved. Built different."
				})]
			})
		]
	});
}
var styles_default = "/assets/styles-C2jg6AoA.css";
var APP_NAME = "VOID";
var Route$5 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "description",
				content: "VOID — streetwear for Indian Gen-Z. Founded by Lekhan."
			},
			{
				name: "theme-color",
				content: "#0f0f0f"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=Syne:wght@600;700;800&display=swap"
			},
			{
				rel: "preconnect",
				href: "https://images.unsplash.com"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		className: "antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", {
			className: "bg-bg text-fg",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
			]
		})]
	})
});
var $$splitComponentImporter$4 = () => import("./routes-DUFl77bt.mjs");
var Route$4 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./checkout-8XHhlb1t.mjs");
var Route$3 = createFileRoute("/checkout")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./privacy-BPe96cg7.mjs");
var Route$2 = createFileRoute("/privacy")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./shop-CdXm0JqA.mjs");
var Route$1 = createFileRoute("/shop")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./terms-B-AKVjc3.mjs");
var Route = createFileRoute("/terms")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var rootRouteChildren = {
	IndexRoute: Route$4.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$5
	}),
	CheckoutRoute: Route$3.update({
		id: "/checkout",
		path: "/checkout",
		getParentRoute: () => Route$5
	}),
	PrivacyRoute: Route$2.update({
		id: "/privacy",
		path: "/privacy",
		getParentRoute: () => Route$5
	}),
	ShopRoute: Route$1.update({
		id: "/shop",
		path: "/shop",
		getParentRoute: () => Route$5
	}),
	TermsRoute: Route.update({
		id: "/terms",
		path: "/terms",
		getParentRoute: () => Route$5
	})
};
var routeTree = Route$5._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { useCart as a, cartTotals as i, cn as n, CATEGORIES as o, inr as r, PRODUCTS as s, router_exports as t };
