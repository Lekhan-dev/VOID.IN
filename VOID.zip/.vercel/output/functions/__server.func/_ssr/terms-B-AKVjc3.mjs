import { x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/terms-B-AKVjc3.js
var import_jsx_runtime = require_jsx_runtime();
function Terms() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto w-[min(720px,92%)] py-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs uppercase tracking-[0.2em] text-muted",
				children: "Legal"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-4xl font-bold",
				children: "Terms of Service"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "Last updated: July 2026"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 space-y-4 text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-bold text-fg",
						children: "1. About VOID"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "VOID is a selfmade streetwear brand founded by Lekhan. These Terms of Service govern your use of the VOID website and any purchases you make through it." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-bold text-fg",
						children: "2. Orders"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Placing an order constitutes an offer to buy. VOID currently operates as a demonstration store unless live Razorpay keys are configured by the store owner." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-bold text-fg",
						children: "3. Content"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "All content on this site is owned by VOID / Lekhan and protected by Indian and international intellectual property laws." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Questions? Reach out via the contact channels on the website. Founded by Lekhan." })
				]
			})
		]
	});
}
//#endregion
export { Terms as component };
