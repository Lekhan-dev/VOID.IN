import { i as __toESM } from "../_runtime.mjs";
import { B as require_react, x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Plus, o as Minus, r as Trash2 } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as useCart, i as cartTotals, r as inr } from "./router-CLN9uA0j.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/checkout-8XHhlb1t.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Checkout() {
	const items = useCart((s) => s.items);
	const setQty = useCart((s) => s.setQty);
	const remove = useCart((s) => s.remove);
	const clear = useCart((s) => s.clear);
	const totals = cartTotals(items);
	const [method, setMethod] = (0, import_react.useState)("razorpay");
	const [key, setKey] = (0, import_react.useState)("");
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [receipt, setReceipt] = (0, import_react.useState)(null);
	const [form, setForm] = (0, import_react.useState)({
		name: "",
		email: "",
		phone: "",
		address: "",
		city: "",
		pincode: "",
		state: ""
	});
	(0, import_react.useEffect)(() => {
		const saved = localStorage.getItem("void_rzp_key");
		if (saved) setKey(saved);
	}, []);
	function complete(extra) {
		const rec = {
			orderId: "VOID-" + Date.now().toString().slice(-8),
			extra,
			name: form.name,
			phone: form.phone,
			address: form.address,
			city: form.city,
			state: form.state,
			pincode: form.pincode,
			items: items.map((i) => ({
				name: i.name,
				qty: i.qty,
				price: i.price
			})),
			total: totals.total
		};
		setReceipt(rec);
		clear();
		toast.success("Order confirmed");
	}
	async function onSubmit(e) {
		e.preventDefault();
		if (items.length === 0) {
			toast.error("Cart is empty");
			return;
		}
		if (!form.name || !form.phone || !form.address) {
			toast.error("Fill name, phone and address");
			return;
		}
		if (method === "cod") {
			complete("Cash on Delivery");
			return;
		}
		const k = key.trim() || localStorage.getItem("void_rzp_key") || "";
		if (!k.startsWith("rzp_test_") && !k.startsWith("rzp_live_")) {
			toast.error("Add a Razorpay Key ID in gateway setup");
			return;
		}
		localStorage.setItem("void_rzp_key", k);
		if (!window.Razorpay) await new Promise((resolve, reject) => {
			const s = document.createElement("script");
			s.src = "https://checkout.razorpay.com/v1/checkout.js";
			s.onload = () => resolve();
			s.onerror = () => reject(/* @__PURE__ */ new Error("gateway"));
			document.body.appendChild(s);
		}).catch(() => {
			toast.error("Payment gateway failed to load");
		});
		if (!window.Razorpay) return;
		setLoading(true);
		const rzp = new window.Razorpay({
			key: k,
			amount: Math.round(totals.total * 100),
			currency: "INR",
			name: "VOID",
			description: "Order · " + items.length + " item(s)",
			prefill: {
				name: form.name,
				email: form.email,
				contact: form.phone
			},
			notes: { brand: "VOID" },
			theme: { color: "#5b8cff" },
			modal: { ondismiss: () => {
				setLoading(false);
				toast.message("Payment cancelled");
			} },
			handler: (response) => {
				setLoading(false);
				complete("Paid via Razorpay · " + (response.razorpay_payment_id || "ok"));
			}
		});
		rzp.on("payment.failed", (resp) => {
			setLoading(false);
			toast.error(resp.error?.description || "Payment failed");
		});
		rzp.open();
	}
	if (receipt) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto w-[min(720px,92%)] py-12 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto grid size-16 place-items-center rounded-full bg-primary text-2xl font-bold",
				children: "✓"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-4 font-display text-3xl font-bold",
				children: "Order confirmed!"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-muted",
				children: "Thanks for supporting VOID. Founded by Lekhan."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 font-mono text-sm text-primary",
				children: [
					receipt.orderId,
					" · ",
					receipt.extra
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 rounded-lg border border-border bg-surface p-4 text-left text-sm text-muted",
				children: [
					receipt.name && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold text-fg",
							children: "Ship to"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
						receipt.name,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
						receipt.phone,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
						receipt.address,
						receipt.city ? `, ${receipt.city}` : "",
						" ",
						receipt.pincode
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 font-semibold text-fg",
						children: "Items"
					}),
					receipt.items.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						i.name,
						" × ",
						i.qty,
						" — ",
						inr(i.price * i.qty)
					] }, i.name)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 font-bold text-primary",
						children: ["Total: ", inr(receipt.total)]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/shop",
				className: "mt-8 inline-flex min-h-12 items-center rounded-full border border-border px-6 font-semibold",
				children: "Keep shopping"
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto grid w-[min(1200px,92%)] gap-10 py-10 lg:grid-cols-[1.1fr_0.9fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs uppercase tracking-[0.2em] text-muted",
				children: "Checkout"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-4xl font-bold",
				children: "Your Order"
			}),
			items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-8 text-muted",
				children: [
					"Cart is empty.",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/shop",
						className: "text-primary",
						children: "Shop the drop"
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-6 space-y-3",
				children: items.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex gap-3 rounded-lg border border-border bg-surface p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: i.img,
						alt: "",
						className: "size-20 rounded-md object-cover"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium",
								children: i.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm tabular-nums text-primary",
								children: inr(i.price)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "grid size-9 place-items-center rounded-md border border-border",
										onClick: () => setQty(i.id, i.qty - 1),
										"aria-label": "Decrease",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "size-3" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "w-6 text-center tabular-nums",
										children: i.qty
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "grid size-9 place-items-center rounded-md border border-border",
										onClick: () => setQty(i.id, i.qty + 1),
										"aria-label": "Increase",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "ml-auto grid size-9 place-items-center text-muted hover:text-hot",
										onClick: () => remove(i.id),
										"aria-label": "Remove",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
									})
								]
							})
						]
					})]
				}, i.id))
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "h-fit rounded-lg border border-border bg-surface p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-bold",
					children: "Summary"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 space-y-2 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted",
								children: "Subtotal"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums",
								children: inr(totals.subtotal)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted",
								children: "Shipping"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums",
								children: totals.shipping ? inr(totals.shipping) : "—"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between border-t border-border pt-2 font-semibold",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Total" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums text-primary",
								children: inr(totals.total)
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-6 space-y-3",
					onSubmit,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold uppercase tracking-widest text-muted",
							children: "Shipping"
						}),
						[
							["name", "Full name"],
							["email", "Email"],
							["phone", "Phone"],
							["address", "Address"],
							["city", "City"],
							["pincode", "PIN code"]
						].map(([k, ph]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							required: k === "name" || k === "phone" || k === "address",
							placeholder: ph,
							value: form[k],
							onChange: (e) => setForm({
								...form,
								[k]: e.target.value
							}),
							className: "min-h-11 w-full rounded-md border border-border bg-bg px-3 text-sm outline-none focus:border-primary"
						}, k)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							value: form.state,
							onChange: (e) => setForm({
								...form,
								state: e.target.value
							}),
							className: "min-h-11 w-full rounded-md border border-border bg-bg px-3 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "Select state"
							}), [
								"Maharashtra",
								"Delhi",
								"Karnataka",
								"Tamil Nadu",
								"Telangana",
								"Gujarat",
								"West Bengal",
								"Rajasthan",
								"Uttar Pradesh",
								"Other"
							].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: s }, s))]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "pt-2 text-xs font-semibold uppercase tracking-widest text-muted",
							children: "Payment gateway"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between rounded-md border border-border bg-bg px-3 py-3 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted",
								children: "Amount to pay"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-bold tabular-nums text-primary",
								children: inr(totals.total)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex cursor-pointer items-center gap-3 rounded-lg border p-3 " + (method === "razorpay" ? "border-primary bg-primary-dim" : "border-border"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "radio",
								name: "pay",
								checked: method === "razorpay",
								onChange: () => setMethod("razorpay")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block font-medium",
								children: "UPI · Card · NetBanking"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-muted",
								children: "GPay, PhonePe, Paytm via Razorpay"
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex cursor-pointer items-center gap-3 rounded-lg border p-3 " + (method === "cod" ? "border-primary bg-primary-dim" : "border-border"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "radio",
								name: "pay",
								checked: method === "cod",
								onChange: () => setMethod("cod")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block font-medium",
								children: "Cash on Delivery"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-muted",
								children: "Pay when your order arrives"
							})] })]
						}),
						method === "razorpay" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
							className: "rounded-md border border-dashed border-border p-3 text-xs text-muted",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
									className: "cursor-pointer font-semibold",
									children: "Store owner: Razorpay key"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2",
									children: "Paste Key ID only (rzp_test_ or rzp_live_). Never the Secret."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: key,
									onChange: (e) => setKey(e.target.value),
									placeholder: "rzp_test_...",
									className: "mt-2 min-h-10 w-full rounded-md border border-border bg-bg px-3"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "submit",
							disabled: loading,
							className: "flex min-h-12 w-full items-center justify-center rounded-full bg-primary font-semibold disabled:opacity-60",
							children: loading ? "Opening gateway…" : method === "cod" ? "Place COD order" : "Pay securely"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-center text-[11px] text-muted",
							children: "Payments processed by Razorpay. VOID never stores card details."
						})
					]
				})
			]
		})]
	});
}
//#endregion
export { Checkout as component };
