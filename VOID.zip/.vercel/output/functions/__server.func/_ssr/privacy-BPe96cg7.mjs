import { x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/privacy-BPe96cg7.js
var import_jsx_runtime = require_jsx_runtime();
function Privacy() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto w-[min(720px,92%)] py-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs uppercase tracking-[0.2em] text-muted",
				children: "Legal"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-4xl font-bold",
				children: "Privacy Policy"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "Last updated: July 2026"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 space-y-4 text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "VOID is a selfmade streetwear brand founded by Lekhan. This Privacy Policy explains how we collect, use, and protect your personal information." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Checkout details (name, phone, address) stay in your browser unless you complete a live payment with Razorpay. We do not sell personal data." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "We may share limited data with shipping partners and payment providers when live payments are enabled." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "For privacy questions, reach out through the website. Founded by Lekhan." })
				]
			})
		]
	});
}
//#endregion
export { Privacy as component };
