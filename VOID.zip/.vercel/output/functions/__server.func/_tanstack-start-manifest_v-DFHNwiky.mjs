//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DFHNwiky.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/checkout",
			"/privacy",
			"/shop",
			"/terms"
		],
		preloads: ["/assets/index-DgXBJAMf.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DgXBJAMf.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Cqt8Rk-w.js", "/assets/product-card-D8YGroru.js"]
	},
	"/checkout": {
		filePath: "/workspace/src/routes/checkout.tsx",
		children: void 0,
		preloads: ["/assets/checkout-BtTlESfh.js", "/assets/plus-nR-AE1h2.js"]
	},
	"/privacy": {
		filePath: "/workspace/src/routes/privacy.tsx",
		children: void 0,
		preloads: ["/assets/privacy-CAy-ngZK.js"]
	},
	"/shop": {
		filePath: "/workspace/src/routes/shop.tsx",
		children: void 0,
		preloads: ["/assets/shop-Cg6Zf_AU.js", "/assets/product-card-D8YGroru.js"]
	},
	"/terms": {
		filePath: "/workspace/src/routes/terms.tsx",
		children: void 0,
		preloads: ["/assets/terms-BN-6eabk.js"]
	}
} });
//#endregion
export { tsrStartManifest };
